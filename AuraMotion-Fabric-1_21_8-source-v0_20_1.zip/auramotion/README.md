# AuraMotion — Fabric 1.21.8 (v0.20.1)

Mod **client-only** de animaciones de jugador en tercera persona, con la misma idea general que Fancy Player Animation (movimiento más fluido y vivo) pero con código **original**. No es un port.

## Qué hace (v0.3)
- Respiración/idle sutil y balanceo del torso al caminar (ya estaba en v0.2).
- **Inclinación al correr (sprint)**: el torso se inclina y la cabeza compensa.
- **Pose en el aire**: brazos hacia fuera al caer, hacia delante al saltar.
- **Impacto al aterrizar**: proporcional a la velocidad de caída.
- **Seguimiento al girar (v0.4)**: el torso se retrasa un poco y los brazos se abren hacia el lado contrario al giro. Signos sin verificar visualmente; si se ve al revés, cambiar el signo en `SecondaryMotion`.
- **Carrera atlética (v0.7, por defecto)**: inclinación fuerte hacia delante, brazos adelantados que bombean al estilo de codos doblados, patada trasera más larga, torso que gira en contra, cabeza estable con rebote. Cambia con `/auramotion runstyle fresh|athletic|action|classic` (`runStyle` en el JSON).
- **Carrera fresh (v0.10, por defecto)**: calibrada con la imagen de referencia: inclinación fuerte con la cabeza siguiéndola, codos a ~90° con los puños al pecho y codos algo abiertos, zancada ancha y pierna trasera pateada hacia arriba. **Necesita `bend on`** para los codos y rodillas; sin eso solo se aproxima con rotaciones.
- **Carrera action (v0.9)**: más energética, inspirada en el "feel" de Actions & Stuff: inclinación más profunda, brazos que empujan más, rodillas altas, codos y rodillas más doblados con `bend on`. `/auramotion runstyle action`.
- **Carrera clásica (v0.6)**: más impulso de brazos y piernas al correr, torsión contraria del torso (la cabeza mira al frente), balanceo de cadera y brazos que se abren un poco.
- **Golpes y minería (v0.6)**: seguimiento del movimiento al atacar o picar con espada (tajo), pico/hacha/pala/azada (golpe cargado). Desplazamiento de peso con las piernas y inclinación del torso, encima de la animación vanilla.
- Transiciones suavizadas e independientes de los FPS; cada jugador tiene fase propia.
- Se desactiva con suavidad al usar ítems, montar, trepar o nadar; no pisa el golpe de ataque.
- Sin primera persona, sin red, sin tocar mecánicas de combate. Solo rotaciones aditivas (no mueve pivotes).

## Emotes por JSON (v0.5)
Se leen de `config/auramotion/animations/*.json` (al primer arranque se crean `wave` y `bow`). Solo los ve el jugador local, sin red. Se cancelan al moverte, saltar, agacharte o usar un ítem. Se ven en tercera persona (F5).

```json
{
  "length": 2.0,
  "loop": false,
  "tracks": {
    "rightArm": [
      {"t": 0.0, "pitch": 0,    "roll": 0},
      {"t": 0.5, "pitch": -150, "roll": 30},
      {"t": 2.0, "pitch": 0,    "roll": 0}
    ]
  }
}
```
Partes: `head`, `body`, `rightArm`, `leftArm`, `rightLeg`, `leftLeg`. Ángulos en grados (`pitch`, `yaw`, `roll`); las partes sin pista no se tocan.

## Comandos (en el juego)
- `/auramotion runstyle fresh|athletic|action|classic`
- `/auramotion perf` muestra cuánta CPU gasta el mod (µs por llamada y ms por segundo); úsalo con y sin `toggle` para comparar FPS
- `/auramotion play <emote>`, `/auramotion stop`, `/auramotion list`
- `/auramotion toggle` activa/desactiva
- `/auramotion reload` recarga `config/auramotion.json`
- `/auramotion intensity <0-2>` multiplicador global

## Config (`config/auramotion.json`)
`enabled`, `intensity`, `idleBreathing`, `walkSway`, `sprintLean`, `airPose`, `landingImpact`, `turnFollow`, `runDetail`, `swingAnimations`, `maxDistance`

## Compilar
Java 21 + Gradle 8.14: `gradle build` → `build/libs/`.
Sin PC: sube la carpeta a un repo de GitHub; el workflow `.github/workflows/build.yml` compila y deja el JAR como artefacto descargable.

## Estado
**Sin compilar ni probar** (el entorno de desarrollo no tiene acceso a las dependencias). Si falla un mixin, el log mostrará el método o descriptor que no coincide con Yarn 1.21.8; hay que corregirlo ahí.

## Animaciones ambientales (v0.11, `ambientAnimations`)
- **Trepar** escaleras y enredaderas: los brazos alcanzan hacia arriba de forma alterna y las piernas suben peldaños.
- **Moverte de lado o hacia atrás:** el torso se inclina hacia el lado de movimiento y hacia atrás al retroceder.
- **Comer y beber:** la cabeza mastica o se inclina hacia atrás al beber; **arco y ballesta:** tensión en brazos y torso.
- **Agacharse:** el torso sigue el balanceo de los brazos y la cadera.
- **Nadar:** el cuerpo ondula.
Todo es solo rotaciones y se apaga con `ambientAnimations: false`.

## Más animaciones (v0.12)
- **Montar:** a caballo el torso se inclina con el galope, rebota suave y las manos van a las riendas; en bote los brazos reman al avanzar.
- **Elytra:** brazos hacia atrás y las piernas aletean.
- **Escudo:** postura de bloqueo con el torso adelantado y las piernas escalonadas.
- **Golpe recibido:** sacudida corta del torso y la cabeza (`hitReaction`, solo cosmética).
- **Herramientas:** hacha (arco amplio), pala (se agacha al cavar), azada (barrido), pico, y lanzar objetos (bola de nieve, huevo, perla...).
- **Cepillo, tridente (carga), cuerno de cabra y caña de pescar.**
- Reposo: pequeños cambios de peso y miradas para que no se vea congelado.

## Corrección de compilación (v0.20.1)
- En Minecraft 1.21.8 los campos de posición de `ModelPart` se llaman `originX/originY/originZ` (no `pivot...`) y el frío se lee con `getFrozenTicks()`. Corregido; era lo único que impedía compilar la v0.20.

## Caídas, daño y más ítems (v0.20)
- **Aterrizaje según la altura:** cuanto más alto caes, más profundo el agachado (las caderas bajan de verdad). Tras una caída de 8 bloques o más, **aterrizaje de superhéroe**: una rodilla y un puño al suelo, que se mantiene un momento y se recupera al moverte.
- **Cayendo:** las piernas se separan un poco. **Levitación y caída lenta:** pose ingrávida con los brazos flotando.
- **Daño con resorte:** al perder vida el cuerpo se sacude hacia atrás y vuelve con un pequeño rebote; la fuerza depende de cuánta vida pierdes y las rodillas se doblan un poco. Se apaga con `hitReaction`.
- **Fuego:** el personaje agita los brazos y se retuerce. **Frío (nieve en polvo):** tiembla y se encoge. **Ahogándote:** forcejea con brazos y piernas.
- **Catalejo:** la cabeza se inclina al visor. **Ballesta cargada:** postura de apuntar con los pies afirmados.

## Calidad adaptable y poca vida (v0.19)
- **Calidad adaptable** (`adaptiveQuality`, activada por defecto): si los FPS se quedan por debajo de 30 durante 2 segundos, el mod baja solo su propio trabajo (nivel 1: menos distancia y sin gestos al quedarte quieto); por debajo de 20, nivel 2 (casi solo lo esencial y sin codos/rodillas). Cuando los FPS suben vuelve a nivel completo. No elimina ninguna animación. `/auramotion status` muestra el nivel actual.
- **Poca vida** (`lowHealthPose`): con 3 corazones o menos el personaje se encorva, respira más fuerte y al caminar cojea; es más marcado cuanto menos vida tenga. Funciona también con los demás jugadores.

## Elytra y gestos al quedarte quieto (v0.17)
- **Elytra:** al planear los brazos se abren; en picado se pegan hacia atrás y las piernas se juntan; con cohete (subiendo) los brazos van hacia delante; en los giros el brazo interior se recoge y el exterior se extiende.
- **Gestos al estar quieto** (`idleFidgets`): cada 8 a 25 segundos, de forma aleatoria, tu personaje (y los demás) mira alrededor, se estira, sacude los brazos, mira su muñeca, pone las manos en la cadera, mueve el cuello, cambia el peso de pie o se balancea sobre los talones. Se interrumpen al moverte, atacar, usar un ítem o hacer un emote.

## Uso de ítems más visible + diagnóstico (v0.16)
- Comer: mastica y la mano sube y baja hacia la boca. Beber: cabeza y torso hacia atrás. Arco/ballesta: el cuerpo se afirma y tiembla más cuanto más tiras. Cepillo, tridente y cuerno: movimientos más marcados. Colocar bloques/interactuar y bloquear con escudo también se notan más.
- **`/auramotion status`** muestra versión/ajustes, si el mixin del modelo se está aplicando de verdad y cómo detecta el ítem que llevas. Si dice que no se aplica, algo falla en esa versión del juego.
- **Importante:** el mod solo anima la **tercera persona** (F5 o verte desde fuera, y otros jugadores). En primera persona no cambia nada.

## Rueda de emotes (v0.15)
Una rueda circular, como la de Free Fire: eliges un emote tocando o haciendo clic en su sector; el círculo del centro (**Parar**) detiene el emote actual. Con más de 6 emotes aparecen páginas (botones `<` `>` o rueda del ratón).
- **Tecla por defecto: `B`.** Cámbiala en *Opciones > Controles > AuraMotion > Abrir rueda de emotes*. Pulsa la tecla otra vez para cerrar.
- En **Zalith** (Android): en el editor de controles crea un botón en pantalla y asígnale la tecla `B` (o la que elijas); también puedes escribir `/auramotion wheel`.
- Al elegir un emote desde la rueda, si estás en primera persona la cámara pasa a **tercera persona frontal** para verte y vuelve al terminar (`emoteAutoThirdPerson`).
- La rueda muestra todos los `.json` de `config/auramotion/animations/`, incluidos los tuyos.

## Más emotes y movimiento (v0.14)
- **Emotes nuevos** (se crean solos en `config/auramotion/animations/` si no existen; no se pisan los tuyos): `salute`, `cheer`, `clap`, `point`, `think`, `shrug`, `flex` y `dance` (en bucle; se detiene con `/auramotion stop` o al moverte), además de `wave` y `bow`. `/auramotion list` los muestra.
- **La columna sigue la mirada:** el torso se inclina un poco al mirar arriba o abajo y gira un poco hacia donde miras.
- **Agacharse y levantarse** con una transición suave en lugar del salto brusco de vanilla.
- **Flotar en el agua:** las piernas patalean y los brazos reman.
- **Caída larga:** brazos y piernas se agitan.

## Espada y combate (v0.13)
- **Combo de espada de 3 golpes:** tajo, tajo inverso y estocada; si golpeas seguido el combo avanza y se reinicia tras una pausa.
- **Ataque en sprint:** estocada más larga hacia delante. **Ataque en caída:** golpe de arriba más amplio.
- **Mazo:** golpe cargado de arriba abajo con todo el torso.
- **Cambiar de arma o herramienta:** el brazo se levanta un instante.
- **Postura lista:** con arma en mano y quieto, los pies se escalonan un poco.
- **Arco o ballesta soltado:** pequeño retroceso del cuerpo.

## Movimiento extra (v0.13)
- **Frenada:** al dejar de correr, el torso se echa atrás, las piernas se plantan y los brazos se abren.
- **Salto:** una rodilla sube y la otra queda atrás; con `bend on` las rodillas se doblan al saltar y más al aterrizar, y el aterrizaje agacha las piernas.

## Rendimiento (v0.13)
- Los jugadores a más de la mitad de `maxDistance` (12 bloques por defecto) se actualizan en fotogramas alternos y no dibujan codos/rodillas; el resto de efectos sigue igual.
- Se guardan en memoria los datos del ítem en mano (antes se consultaban cada fotograma) y la pose de planeo.
- La medición de `/auramotion perf` ahora es opcional: la primera vez empieza a medir, la segunda muestra el resultado y `/auramotion perf off` la apaga; mientras está apagada no gasta nada.
- No se eliminó ninguna animación ni opción.

## Corrección v0.10.1
- La cabeza ya no mira hacia arriba al inclinarse: antes se le restaba ángulo por error.
- El torso ahora se inclina pivotando en la cadera (cuello y hombros se adelantan), así no se separa de las piernas.

## Codos y rodillas reales (v0.8, EXPERIMENTAL, apagado por defecto)
`/auramotion bend on|off` (o `bentLimbs` en el JSON) y reinicia el juego (o F3+T). Parte cada brazo y pierna en dos mitades al cargar el modelo para poder doblarlas.
- Armadura e ítems usan modelos rígidos: el codo no se dobla si llevas pechera o sostienes algo con ese brazo, ni la rodilla si llevas pantalones o botas.
- Si el nombre del método del modelo cambia en 1.21.8, simplemente no hace nada (vuelve al modelo vanilla).
- Puede chocar con mods que cambian el modelo del jugador.

## Límite conocido
El modelo vanilla tiene brazos y piernas rígidos (sin codos ni rodillas). La carrera atlética los imita con rotaciones; para codos y rodillas reales haría falta un modelo con extremidades divididas (como hacen los packs con modelos de entidad personalizados), que cuesta más rendimiento.

## Pendiente / ideas
- Animaciones personalizadas por JSON (emotes), con API para otros mods
- Cabeza/cuello con retardo (necesita historial de rotación)
- Menú de ajustes (Mod Menu) si no se quiere depender solo de comandos

## Rendimiento (pensado para equipos básicos)
- Los jugadores a más de `maxDistance` bloques (24 por defecto) no gastan nada.
- Sin `exp()` ni asignaciones en el camino caliente; mapa por id de entidad (fastutil); solo rotaciones.
- `/auramotion perf` mide el costo real en tu dispositivo. Si bajan los FPS, baja `maxDistance`, desactiva `runDetail`/`turnFollow` o pon `intensity` en 0.
- No se han medido FPS en un dispositivo real todavía: hay que probarlo.
