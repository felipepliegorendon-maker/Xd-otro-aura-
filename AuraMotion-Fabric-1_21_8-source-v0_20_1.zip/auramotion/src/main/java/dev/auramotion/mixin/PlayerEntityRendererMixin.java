package dev.auramotion.mixin;

import dev.auramotion.anim.AuraMotionStateAccess;
import dev.auramotion.anim.BentLimbs;
import dev.auramotion.anim.MotionTracker;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Third-person only: collects motion data when the world renderer builds the player's render state. */
@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin {
    /** First-person arm uses the same model: make sure no stale elbow bend is left on it. */
    @Inject(method = {"renderRightArm", "renderLeftArm"}, at = @At("HEAD"))
    private void auramotion$firstPersonArm(CallbackInfo ci) {
        BentLimbs.resetFor(((PlayerEntityRenderer) (Object) this).getModel());
    }

    @Inject(
            method = "updateRenderState(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V",
            at = @At("TAIL")
    )
    private void auramotion$collect(AbstractClientPlayerEntity player, PlayerEntityRenderState state,
                                    float tickDelta, CallbackInfo ci) {
        ((AuraMotionStateAccess) (Object) state).auramotion$setMotion(MotionTracker.update(player, tickDelta));
    }
}
