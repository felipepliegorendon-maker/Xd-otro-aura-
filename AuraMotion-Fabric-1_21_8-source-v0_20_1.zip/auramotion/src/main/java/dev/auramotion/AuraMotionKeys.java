package dev.auramotion;

import dev.auramotion.anim.AnimationManager;
import dev.auramotion.config.AuraMotionConfig;
import dev.auramotion.ui.EmoteWheelScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/** Key binding that opens the emote wheel (change it in Options > Controls > AuraMotion). */
public final class AuraMotionKeys {
    public static KeyBinding OPEN;
    private static boolean pending;
    private static boolean revertToFirstPerson;

    private AuraMotionKeys() {
    }

    public static void init() {
        OPEN = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.auramotion.wheel", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "key.categories.auramotion"));
        ClientTickEvents.END_CLIENT_TICK.register(AuraMotionKeys::tick);
    }

    /** Opens the wheel on the next tick (after a chat command's screen has closed). */
    public static void requestWheel() {
        pending = true;
    }

    /** Called when an emote is started from the wheel: show the player from the front if in first person. */
    public static void onEmoteStarted() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (AuraMotionConfig.get().emoteAutoThirdPerson && mc.options.getPerspective().isFirstPerson()) {
            mc.options.setPerspective(Perspective.THIRD_PERSON_FRONT);
            revertToFirstPerson = true;
        }
    }

    private static void tick(MinecraftClient mc) {
        dev.auramotion.anim.Quality.tick(mc);
        boolean pressed = false;
        while (OPEN.wasPressed()) {
            pressed = true;
        }
        if ((pressed || pending) && mc.currentScreen == null && mc.player != null) {
            pending = false;
            mc.setScreen(new EmoteWheelScreen());
        }
        if (revertToFirstPerson && !AnimationManager.isPlaying()) {
            revertToFirstPerson = false;
            mc.options.setPerspective(Perspective.FIRST_PERSON);
        }
    }
}
