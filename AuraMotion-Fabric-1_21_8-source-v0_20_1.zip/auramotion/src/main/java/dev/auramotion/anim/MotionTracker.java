package dev.auramotion.anim;

import dev.auramotion.config.AuraMotionConfig;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Tracks lightweight, frame-rate independent motion data per player.
 * Render thread only. No exp()/sqrt() in the hot path; players beyond maxDistance are skipped.
 */
public final class MotionTracker {
    private static final Int2ObjectOpenHashMap<PlayerMotionState> STATES = new Int2ObjectOpenHashMap<>();
    private static int calls;
    /** Ordinal of the gliding pose (its enum name differs between mappings), resolved once. */
    private static final int GLIDE_ORDINAL = glideOrdinal();

    private static int glideOrdinal() {
        for (EntityPose p : EntityPose.values()) {
            String n = p.name();
            if (n.equals("GLIDING") || n.equals("FALL_FLYING")) {
                return p.ordinal();
            }
        }
        return -1;
    }

    private MotionTracker() {
    }

    public static void clear() {
        STATES.clear();
    }

    /** @return the smoothed state for this player, or null when AuraMotion is off or the player is far away. */
    public static PlayerMotionState update(AbstractClientPlayerEntity player, float tickDelta) {
        AuraMotionConfig cfg = AuraMotionConfig.get();
        if (!cfg.enabled || cfg.intensity <= 0.0F) {
            return null;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean local = player == mc.player;
        boolean far = false;
        if (!local && mc.player != null) {
            double d2 = player.squaredDistanceTo(mc.player);
            double max = cfg.maxDistance * Quality.distanceScale();
            if (d2 > max * max) {
                return null; // distance LOD: zero work for far players
            }
            double near = max * 0.5;
            far = d2 > near * near;
        }
        long now = System.nanoTime();
        Diagnostics.trackerCalls++;
        PlayerMotionState s = compute(player, tickDelta, local, far, now);
        if (local) {
            Diagnostics.local = s;
        }
        if (PerfStats.enabled) {
            PerfStats.add(System.nanoTime() - now);
        }
        return s;
    }

    private static PlayerMotionState compute(AbstractClientPlayerEntity player, float tickDelta, boolean local,
                                             boolean far, long now) {
        int id = player.getId();
        PlayerMotionState s = STATES.get(id);
        if (s == null) {
            s = new PlayerMotionState();
            s.phase = (id & 1023) / 1023.0F * MathHelper.TAU;
            s.rng = id * 0x9E3779B9 + 12345;
            s.nextFidgetAt = 6.0F + 10.0F * rand(s);
            STATES.put(id, s);
        }
        s.lastSeenNanos = now;
        s.local = local;
        s.far = far;
        if (far) {
            // Players in the mid-distance band only need an update every other frame.
            s.skipToggle = !s.skipToggle;
            if (s.skipToggle && s.lastNanos != 0L) {
                return s;
            }
        }

        if ((++calls & 511) == 0) {
            long limit = now - 10_000_000_000L;
            STATES.values().removeIf(v -> v.lastSeenNanos < limit);
        }

        Vec3d pos = player.getLerpedPos(tickDelta);
        if (s.lastNanos == 0L) {
            s.lastNanos = now;
            s.lastX = pos.x;
            s.lastY = pos.y;
            s.lastZ = pos.z;
            return s;
        }

        float dt = (now - s.lastNanos) / 1.0E9F;
        if (dt < 0.0005F) {
            return s; // Same frame (or extremely fast); keep current values.
        }
        dt = Math.min(dt, 0.25F);
        s.lastNanos = now;

        double dx = pos.x - s.lastX;
        double dy = pos.y - s.lastY;
        double dz = pos.z - s.lastZ;
        s.lastX = pos.x;
        s.lastY = pos.y;
        s.lastZ = pos.z;

        // Teleport / respawn / dimension change: drop transient state.
        if (dx * dx + dy * dy + dz * dz > 64.0D) {
            s.air = s.rise = s.fall = s.land = s.lean = s.turn = s.swing = 0.0F;
            s.fwd = s.side = s.climb = s.useW = 0.0F;
            s.rideW = s.blockW = s.hurt = s.fishW = s.glideW = 0.0F;
            s.skid = s.speedS = s.equip = s.release = 0.0F;
            s.peakFallDist = s.hero = 0.0F;
            s.yawInit = false;
            s.airTime = 0.0F;
            s.peakFall = 0.0F;
            s.wasOnGround = true;
            return s;
        }

        // Turning speed (deg/s -> -1..1), smoothed. Wrapped so 359 -> 1 is a small step.
        float yaw = player.getYaw(tickDelta);
        float turnTarget = 0.0F;
        if (s.yawInit) {
            turnTarget = MathHelper.clamp(MathHelper.wrapDegrees(yaw - s.lastYaw) / dt / 540.0F, -1.0F, 1.0F);
        }
        s.lastYaw = yaw;
        s.yawInit = true;
        s.turn = approach(s.turn, turnTarget, 9.0F, dt);

        // Movement direction relative to where the player looks (strafe / backpedal).
        float speedXZ = (float) (Math.sqrt(dx * dx + dz * dz) / dt / 20.0D);
        float fwdTarget = 0.0F;
        float sideTarget = 0.0F;
        if (speedXZ > 0.03F) {
            float yr = yaw * (MathHelper.PI / 180.0F);
            float sy = MathHelper.sin(yr);
            float cy = MathHelper.cos(yr);
            double dist = Math.sqrt(dx * dx + dz * dz);
            fwdTarget = (float) ((-dx * sy + dz * cy) / dist);
            sideTarget = (float) ((-dx * cy - dz * sy) / dist);
        }
        s.fwd = approach(s.fwd, fwdTarget, 10.0F, dt);
        s.side = approach(s.side, sideTarget, 10.0F, dt);

        // Velocities in blocks per tick (vanilla units).
        float vy = (float) (dy / dt / 20.0D);
        float speed = (float) (Math.sqrt(dx * dx + dz * dz) / dt / 20.0D);

        boolean onGround = player.isOnGround();
        boolean busy = player.isUsingItem() || player.hasVehicle() || player.isClimbing()
                || player.isTouchingWater();
        boolean airborne = !onGround && !busy;

        // Crouch transition and treading water.
        boolean crouching = player.getPose() == EntityPose.CROUCHING;
        if (crouching != s.wasCrouch) {
            s.wasCrouch = crouching;
            s.crouchT = 0.0F;
        }
        s.crouchT = Math.min(1.0F, s.crouchT + dt / 0.15F);
        boolean treading = player.isTouchingWater() && !onGround && player.getPose() == EntityPose.STANDING;
        s.treadW = approach(s.treadW, treading ? 1.0F : 0.0F, 8.0F, dt);

        // Climbing (ladders, vines): arms and legs alternate with the vertical movement.
        boolean climbing = player.isClimbing() && !onGround;
        s.climb = approach(s.climb, climbing ? 1.0F : 0.0F, 12.0F, dt);
        if (climbing) {
            s.climbPhase += (float) dy * 9.0F;
        }

        // Item use: eating / drinking / bow tension.
        boolean using = player.isUsingItem();
        if (using) {
            s.useKind = useKind(player.getActiveItem());
            s.drawP = MathHelper.clamp(player.getItemUseTime() / 20.0F, 0.0F, 1.0F);
        }
        if (s.wasUsing && !using && s.useKind == 2) {
            s.release = 1.0F; // bow/crossbow let go: small recoil
        }
        s.wasUsing = using;
        s.release = Math.max(0.0F, s.release - dt * 4.0F);
        s.useW = approach(s.useW, using && s.useKind > 0 ? 1.0F : 0.0F, 10.0F, dt);

        // Riding: horse gallop bob / rowing a boat.
        boolean riding = player.hasVehicle();
        if (riding) {
            Entity v = player.getVehicle();
            if (v != null && v.getId() != s.vehicleId) {
                s.vehicleId = v.getId();
                s.mountKind = mountKind(v);
            }
            s.rideSpeed = approach(s.rideSpeed, speed, 6.0F, dt);
            s.ridePhase += dt * (s.mountKind == 1 ? 2.5F + speed * 45.0F : 4.0F + speed * 30.0F);
        } else {
            s.vehicleId = Integer.MIN_VALUE;
            s.rideSpeed = approach(s.rideSpeed, 0.0F, 6.0F, dt);
        }
        s.rideW = approach(s.rideW, riding ? 1.0F : 0.0F, 8.0F, dt);

        // Elytra: the pose enum name differs between mappings, so compare by name.
        s.glide = GLIDE_ORDINAL >= 0 && player.getPose().ordinal() == GLIDE_ORDINAL;
        s.glideW = approach(s.glideW, s.glide ? 1.0F : 0.0F, 8.0F, dt);

        s.weak = approach(s.weak, MathHelper.clamp((7.0F - player.getHealth()) / 5.0F, 0.0F, 1.0F), 3.0F, dt);
        s.blockW = approach(s.blockW, player.isBlocking() ? 1.0F : 0.0F, 12.0F, dt);
        float hurtTarget = player.hurtTime > 0 ? player.hurtTime / (float) Math.max(1, player.maxHurtTime) : 0.0F;
        s.hurt = approach(s.hurt, hurtTarget, 30.0F, dt);
        s.fishW = approach(s.fishW, player.fishHook != null ? 1.0F : 0.0F, 8.0F, dt);

        // Moving, jumping, sneaking or interacting cancels an emote.
        if (local && AnimationManager.isActive()
                && (speed > 0.04F || !onGround || busy || player.isSneaking())) {
            AnimationManager.stop();
        }

        // Master weight: fade effects out instead of popping.
        s.master = approach(s.master, busy ? 0.0F : 1.0F, 12.0F, dt);

        // Attack / mining swing.
        float swingP = player.getHandSwingProgress(tickDelta);
        s.swing = swingP;
        s.swingRight = player.getMainArm() == Arm.RIGHT;

        // Held item: tag lookups only when the item actually changes.
        ItemStack heldStack = player.getMainHandStack();
        Item heldItem = heldStack.getItem();
        if (heldItem != s.lastItem) {
            if (s.lastItem != null) {
                s.equip = 1.0F; // weapon/tool switch flourish
            }
            s.lastItem = heldItem;
            s.heldStyle = swingStyle(heldStack);
            s.heldWeapon = s.heldStyle == 1 || s.heldStyle == 4 || s.heldStyle == 7;
        }
        s.equip = Math.max(0.0F, s.equip - dt * 3.0F);
        s.ready = approach(s.ready, s.heldWeapon ? 1.0F : 0.0F, 6.0F, dt);

        if (swingP > 0.0F) {
            s.swingStyle = s.heldStyle;
            // New swing (progress restarted): advance the 3-step sword combo if the last swing was recent.
            if (s.prevSwing <= 0.0F || swingP < s.prevSwing - 0.3F) {
                s.combo = (now - s.lastSwingNanos < 900_000_000L) ? (s.combo + 1) % 3 : 0;
                s.lastSwingNanos = now;
            }
        }
        s.prevSwing = swingP;

        // Damage: a springy flinch whose strength follows how much health was lost.
        float hp = player.getHealth();
        if (s.lastHealth > 0.0F && hp < s.lastHealth - 0.05F) {
            s.flinchSev = MathHelper.clamp((s.lastHealth - hp) / 6.0F, 0.25F, 1.0F);
            s.flinchT = 0.0F;
        }
        s.lastHealth = hp;
        s.flinchT = Math.min(1.0F, s.flinchT + dt);
        s.fireW = approach(s.fireW, player.isOnFire() ? 1.0F : 0.0F, 8.0F, dt);
        s.freezeW = approach(s.freezeW, (player.getFrozenTicks() > 20) ? 1.0F : 0.0F, 6.0F, dt);
        s.drownW = approach(s.drownW, (player.isSubmergedInWater() && player.getAir() < 60) ? 1.0F : 0.0F, 6.0F, dt);

        // Levitation / slow falling: floating pose.
        boolean floaty = !onGround && (player.hasStatusEffect(StatusEffects.LEVITATION)
                || player.hasStatusEffect(StatusEffects.SLOW_FALLING));
        s.floatW = approach(s.floatW, floaty ? 1.0F : 0.0F, 6.0F, dt);

        // Loaded crossbow held: aiming stance.
        boolean charged = false;
        if (heldStack.isOf(Items.CROSSBOW)) {
            ChargedProjectilesComponent cp = heldStack.get(DataComponentTypes.CHARGED_PROJECTILES);
            charged = cp != null && !cp.isEmpty();
        }
        s.xbowW = approach(s.xbowW, charged ? 1.0F : 0.0F, 8.0F, dt);

        // Idle gestures: only while really standing still (no emote, item use, swing, water, climbing).
        boolean still = speed < 0.01F && onGround && !busy && swingP <= 0.0F && !using
                && s.climb < 0.1F && player.getPose() == EntityPose.STANDING
                && !(local && AnimationManager.isPlaying());
        if (still) {
            s.stillT += dt;
        } else if (s.stillT > 0.0F) {
            s.stillT = 0.0F;
            s.nextFidgetAt = 6.0F + 10.0F * rand(s);
        }
        if (s.fidget >= 0) {
            if (!still) {
                s.fidgetW = approach(s.fidgetW, 0.0F, 14.0F, dt);
                if (s.fidgetW < 0.02F) {
                    s.fidget = -1;
                    s.fidgetW = 0.0F;
                }
            } else {
                s.fidgetT += dt;
                if (s.fidgetT >= IdleFidgets.length(s.fidget)) {
                    s.fidget = -1;
                    s.fidgetW = 0.0F;
                    s.nextFidgetAt = s.stillT + 8.0F + 14.0F * rand(s);
                } else {
                    s.fidgetW = approach(s.fidgetW, 1.0F, 12.0F, dt);
                }
            }
        } else if (still && s.stillT >= s.nextFidgetAt) {
            s.fidget = Math.min(IdleFidgets.COUNT - 1, (int) (rand(s) * IdleFidgets.COUNT));
            s.fidgetT = 0.0F;
            s.fidgetW = 0.0F;
        }
        if (AuraMotionConfig.get().bentLimbs) {
            s.chestArmor = !player.getEquippedStack(EquipmentSlot.CHEST).isEmpty();
            s.legArmor = !player.getEquippedStack(EquipmentSlot.LEGS).isEmpty()
                    || !player.getEquippedStack(EquipmentSlot.FEET).isEmpty();
            boolean mainHeld = !player.getMainHandStack().isEmpty();
            boolean offHeld = !player.getOffHandStack().isEmpty();
            boolean mainRight = player.getMainArm() == Arm.RIGHT;
            s.rightHandBusy = mainRight ? mainHeld : offHeld;
            s.leftHandBusy = mainRight ? offHeld : mainHeld;
        }
        // Idle/air arm additions fade out while the arm is busy swinging.
        s.armWeight = approach(s.armWeight, swingP > 0.0F ? 0.0F : 1.0F, 18.0F, dt);

        // Sprint lean.
        float leanTarget = (player.isSprinting() && onGround && !busy)
                ? MathHelper.clamp(speed / 0.28F, 0.0F, 1.0F) : 0.0F;
        s.lean = approach(s.lean, leanTarget, 8.0F, dt);
        // Braking: the sprint lean is still fading while the player has already stopped.
        s.speedS = approach(s.speedS, speed, 10.0F, dt);
        s.vyS = approach(s.vyS, vy, 8.0F, dt);
        s.skid = s.lean * (1.0F - MathHelper.clamp(s.speedS / 0.15F, 0.0F, 1.0F));

        // Airborne weight with a small delay to ignore stairs/slabs/step-downs.
        s.airTime = airborne ? s.airTime + dt : 0.0F;
        boolean inAir = s.airTime > 0.12F;
        s.air = approach(s.air, inAir ? 1.0F : 0.0F, inAir ? 10.0F : 14.0F, dt);
        s.rise = approach(s.rise, inAir ? MathHelper.clamp(vy / 0.42F, 0.0F, 1.0F) : 0.0F, 12.0F, dt);
        s.fall = approach(s.fall, inAir ? MathHelper.clamp(-vy / 0.9F, 0.0F, 1.0F) : 0.0F, 10.0F, dt);

        if (inAir) {
            s.peakFall = Math.min(s.peakFall, vy);
            s.peakFallDist = Math.max(s.peakFallDist, (float) player.fallDistance);
        }

        // Landing impulse proportional to the fall speed reached.
        if (onGround && !s.wasOnGround) {
            if (s.peakFall < -0.2F) {
                float impulse = MathHelper.clamp((-s.peakFall - 0.2F) / 0.7F, 0.0F, 1.0F);
                s.land = Math.max(s.land, 0.25F + 0.75F * impulse);
            }
            if (s.peakFallDist > 3.0F) { // the longer the fall, the harder the landing
                s.land = Math.max(s.land, 0.3F + 0.7F * MathHelper.clamp(s.peakFallDist / 10.0F, 0.0F, 1.0F));
            }
            if (s.peakFallDist >= 8.0F) {
                s.hero = 1.0F; // superhero landing after a very long fall
            }
            s.peakFall = 0.0F;
            s.peakFallDist = 0.0F;
        }
        s.wasOnGround = onGround;

        s.land /= 1.0F + 6.5F * dt; // cheap exponential-like decay
        s.hero = Math.max(0.0F, s.hero - dt * (speed > 0.05F ? 3.0F : 0.9F));
        if (s.land < 0.005F) {
            s.land = 0.0F;
        }
        return s;
    }

    private static float rand(PlayerMotionState s) {
        s.rng = s.rng * 1664525 + 1013904223;
        return ((s.rng >>> 8) & 0xFFFF) / 65536.0F;
    }

    private static int swingStyle(ItemStack h) {
        if (h.isIn(ItemTags.SWORDS)) {
            return 1;
        }
        if (h.isOf(Items.MACE)) {
            return 7;
        }
        if (h.isIn(ItemTags.PICKAXES)) {
            return 2;
        }
        if (h.isIn(ItemTags.AXES)) {
            return 4;
        }
        if (h.isIn(ItemTags.SHOVELS)) {
            return 5;
        }
        if (h.isIn(ItemTags.HOES)) {
            return 6;
        }
        if (h.isOf(Items.SNOWBALL) || h.isOf(Items.EGG) || h.isOf(Items.ENDER_PEARL)
                || h.isOf(Items.SPLASH_POTION) || h.isOf(Items.LINGERING_POTION)
                || h.isOf(Items.EXPERIENCE_BOTTLE) || h.isOf(Items.WIND_CHARGE)) {
            return 3; // throwables
        }
        return 0;
    }

    private static int mountKind(Entity v) {
        if (v instanceof AbstractHorseEntity) {
            return 1;
        }
        String key = v.getType().getTranslationKey();
        return (key.contains("boat") || key.contains("raft")) ? 2 : 3;
    }

    private static int useKind(ItemStack a) {
        if (a.isOf(Items.BRUSH)) {
            return 4;
        }
        if (a.isOf(Items.SPYGLASS)) {
            return 5;
        }
        if (a.isOf(Items.TRIDENT)) {
            return 6;
        }
        if (a.isOf(Items.GOAT_HORN)) {
            return 7;
        }
        if (a.isOf(Items.BOW) || a.isOf(Items.CROSSBOW)) {
            return 2;
        }
        if (a.isOf(Items.POTION) || a.isOf(Items.MILK_BUCKET) || a.isOf(Items.HONEY_BOTTLE)) {
            return 3;
        }
        return a.contains(DataComponentTypes.FOOD) ? 1 : 0;
    }

    /** Frame-rate independent smoothing without exp(): implicit Euler step. */
    private static float approach(float current, float target, float rate, float dt) {
        float x = rate * dt;
        return current + (target - current) * (x / (1.0F + x));
    }
}
