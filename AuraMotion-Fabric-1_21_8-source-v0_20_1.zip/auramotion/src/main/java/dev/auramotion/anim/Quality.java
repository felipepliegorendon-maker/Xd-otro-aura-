package dev.auramotion.anim;

import dev.auramotion.config.AuraMotionConfig;
import net.minecraft.client.MinecraftClient;

/**
 * Adaptive quality: when the game's FPS stays low the mod does less work on its own and restores everything when the
 * FPS recovers. Nothing is removed permanently. level 0 = full, 1 = reduced (shorter range, no idle gestures),
 * 2 = minimal (very short range, no ambient extras, no elbow/knee posing).
 */
public final class Quality {
    public static int level;
    private static long nextCheck;
    private static int lowSeconds;
    private static int highSeconds;

    private Quality() {
    }

    /** Call once per client tick; it only does real work once per second. */
    public static void tick(MinecraftClient mc) {
        if (!AuraMotionConfig.get().adaptiveQuality) {
            level = 0;
            return;
        }
        long now = System.nanoTime();
        if (now < nextCheck) {
            return;
        }
        nextCheck = now + 1_000_000_000L;
        int fps = mc.getCurrentFps();
        if (fps <= 0) {
            return;
        }
        int target = fps < 20 ? 2 : (fps < 30 ? 1 : 0);
        if (target > level) {
            highSeconds = 0;
            if (++lowSeconds >= 2) {
                level = target;
                lowSeconds = 0;
            }
        } else if (fps > (level == 2 ? 30 : 40)) {
            lowSeconds = 0;
            if (++highSeconds >= 3) {
                level = Math.max(0, level - 1);
                highSeconds = 0;
            }
        } else {
            lowSeconds = 0;
            highSeconds = 0;
        }
    }

    public static float distanceScale() {
        return level == 0 ? 1.0F : (level == 1 ? 0.6F : 0.3F);
    }
}
