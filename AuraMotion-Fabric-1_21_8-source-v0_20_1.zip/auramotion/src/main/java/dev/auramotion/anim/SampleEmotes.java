package dev.auramotion.anim;

import java.util.LinkedHashMap;
import java.util.Map;

/** Sample emotes written to config/auramotion/animations/ when the file does not exist yet (never overwritten). */
public final class SampleEmotes {
    public static final Map<String, String> SAMPLES = new LinkedHashMap<>();

    static {
        SAMPLES.put("wave", """
                {"length":2.0,"loop":false,"tracks":{"rightArm":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.3,"pitch":-150,"yaw":0,"roll":10},{"t":0.6,"pitch":-150,"yaw":0,"roll":35},{"t":0.9,"pitch":-150,"yaw":0,"roll":10},{"t":1.2,"pitch":-150,"yaw":0,"roll":35},{"t":1.5,"pitch":-150,"yaw":0,"roll":10},{"t":2.0,"pitch":0,"yaw":0,"roll":0}]}}
                """);
        SAMPLES.put("bow", """
                {"length":2.0,"loop":false,"tracks":{"body":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.6,"pitch":40,"yaw":0,"roll":0},{"t":1.3,"pitch":40,"yaw":0,"roll":0},{"t":2.0,"pitch":0,"yaw":0,"roll":0}],"head":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.6,"pitch":15,"yaw":0,"roll":0},{"t":1.3,"pitch":15,"yaw":0,"roll":0},{"t":2.0,"pitch":0,"yaw":0,"roll":0}]}}
                """);
        SAMPLES.put("salute", """
                {"length":1.8,"loop":false,"tracks":{"rightArm":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.3,"pitch":-125,"yaw":0,"roll":10},{"t":1.3,"pitch":-125,"yaw":0,"roll":10},{"t":1.8,"pitch":0,"yaw":0,"roll":0}],"head":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.3,"pitch":-6,"yaw":0,"roll":0},{"t":1.3,"pitch":-6,"yaw":0,"roll":0},{"t":1.8,"pitch":0,"yaw":0,"roll":0}]}}
                """);
        SAMPLES.put("cheer", """
                {"length":2.2,"loop":false,"tracks":{"rightArm":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.3,"pitch":-170,"yaw":0,"roll":15},{"t":0.7,"pitch":-170,"yaw":0,"roll":35},{"t":1.1,"pitch":-170,"yaw":0,"roll":15},{"t":1.5,"pitch":-170,"yaw":0,"roll":35},{"t":1.9,"pitch":-170,"yaw":0,"roll":15},{"t":2.2,"pitch":0,"yaw":0,"roll":0}],"leftArm":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.3,"pitch":-170,"yaw":0,"roll":-15},{"t":0.7,"pitch":-170,"yaw":0,"roll":-35},{"t":1.1,"pitch":-170,"yaw":0,"roll":-15},{"t":1.5,"pitch":-170,"yaw":0,"roll":-35},{"t":1.9,"pitch":-170,"yaw":0,"roll":-15},{"t":2.2,"pitch":0,"yaw":0,"roll":0}],"head":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.3,"pitch":-12,"yaw":0,"roll":0},{"t":1.9,"pitch":-12,"yaw":0,"roll":0},{"t":2.2,"pitch":0,"yaw":0,"roll":0}],"body":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.3,"pitch":-5,"yaw":0,"roll":0},{"t":1.9,"pitch":-5,"yaw":0,"roll":0},{"t":2.2,"pitch":0,"yaw":0,"roll":0}]}}
                """);
        SAMPLES.put("clap", """
                {"length":2.0,"loop":false,"tracks":{"rightArm":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.25,"pitch":-75,"yaw":0,"roll":-5},{"t":0.45,"pitch":-75,"yaw":0,"roll":-30},{"t":0.65,"pitch":-75,"yaw":0,"roll":-5},{"t":0.85,"pitch":-75,"yaw":0,"roll":-30},{"t":1.05,"pitch":-75,"yaw":0,"roll":-5},{"t":1.25,"pitch":-75,"yaw":0,"roll":-30},{"t":1.45,"pitch":-75,"yaw":0,"roll":-5},{"t":1.7,"pitch":-75,"yaw":0,"roll":-30},{"t":2.0,"pitch":0,"yaw":0,"roll":0}],"leftArm":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.25,"pitch":-75,"yaw":0,"roll":5},{"t":0.45,"pitch":-75,"yaw":0,"roll":30},{"t":0.65,"pitch":-75,"yaw":0,"roll":5},{"t":0.85,"pitch":-75,"yaw":0,"roll":30},{"t":1.05,"pitch":-75,"yaw":0,"roll":5},{"t":1.25,"pitch":-75,"yaw":0,"roll":30},{"t":1.45,"pitch":-75,"yaw":0,"roll":5},{"t":1.7,"pitch":-75,"yaw":0,"roll":30},{"t":2.0,"pitch":0,"yaw":0,"roll":0}]}}
                """);
        SAMPLES.put("point", """
                {"length":1.8,"loop":false,"tracks":{"rightArm":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.3,"pitch":-88,"yaw":0,"roll":-3},{"t":1.4,"pitch":-88,"yaw":0,"roll":-3},{"t":1.8,"pitch":0,"yaw":0,"roll":0}],"body":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.3,"pitch":0,"yaw":-8,"roll":0},{"t":1.4,"pitch":0,"yaw":-8,"roll":0},{"t":1.8,"pitch":0,"yaw":0,"roll":0}]}}
                """);
        SAMPLES.put("think", """
                {"length":2.6,"loop":false,"tracks":{"rightArm":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.4,"pitch":-95,"yaw":0,"roll":-40},{"t":2.1,"pitch":-95,"yaw":0,"roll":-40},{"t":2.6,"pitch":0,"yaw":0,"roll":0}],"leftArm":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.4,"pitch":-40,"yaw":0,"roll":-10},{"t":2.1,"pitch":-40,"yaw":0,"roll":-10},{"t":2.6,"pitch":0,"yaw":0,"roll":0}],"head":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.4,"pitch":12,"yaw":0,"roll":6},{"t":2.1,"pitch":12,"yaw":0,"roll":6},{"t":2.6,"pitch":0,"yaw":0,"roll":0}],"body":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.4,"pitch":4,"yaw":0,"roll":0},{"t":2.1,"pitch":4,"yaw":0,"roll":0},{"t":2.6,"pitch":0,"yaw":0,"roll":0}]}}
                """);
        SAMPLES.put("shrug", """
                {"length":1.6,"loop":false,"tracks":{"rightArm":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.25,"pitch":-25,"yaw":0,"roll":28},{"t":1.2,"pitch":-25,"yaw":0,"roll":28},{"t":1.6,"pitch":0,"yaw":0,"roll":0}],"leftArm":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.25,"pitch":-25,"yaw":0,"roll":-28},{"t":1.2,"pitch":-25,"yaw":0,"roll":-28},{"t":1.6,"pitch":0,"yaw":0,"roll":0}],"head":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.25,"pitch":0,"yaw":0,"roll":8},{"t":1.2,"pitch":0,"yaw":0,"roll":8},{"t":1.6,"pitch":0,"yaw":0,"roll":0}]}}
                """);
        SAMPLES.put("flex", """
                {"length":2.4,"loop":false,"tracks":{"rightArm":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.3,"pitch":0,"yaw":0,"roll":85},{"t":0.9,"pitch":0,"yaw":0,"roll":95},{"t":1.4,"pitch":0,"yaw":0,"roll":85},{"t":1.9,"pitch":0,"yaw":0,"roll":95},{"t":2.4,"pitch":0,"yaw":0,"roll":0}],"leftArm":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.3,"pitch":0,"yaw":0,"roll":-85},{"t":0.9,"pitch":0,"yaw":0,"roll":-95},{"t":1.4,"pitch":0,"yaw":0,"roll":-85},{"t":1.9,"pitch":0,"yaw":0,"roll":-95},{"t":2.4,"pitch":0,"yaw":0,"roll":0}],"body":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.3,"pitch":-4,"yaw":0,"roll":0},{"t":1.9,"pitch":-4,"yaw":0,"roll":0},{"t":2.4,"pitch":0,"yaw":0,"roll":0}],"head":[{"t":0,"pitch":0,"yaw":0,"roll":0},{"t":0.3,"pitch":-5,"yaw":0,"roll":0},{"t":1.9,"pitch":-5,"yaw":0,"roll":0},{"t":2.4,"pitch":0,"yaw":0,"roll":0}]}}
                """);
        SAMPLES.put("dance", """
                {"length":2.4,"loop":true,"tracks":{"rightArm":[{"t":0,"pitch":-150,"yaw":0,"roll":15},{"t":0.6,"pitch":-50,"yaw":0,"roll":30},{"t":1.2,"pitch":-150,"yaw":0,"roll":15},{"t":1.8,"pitch":-50,"yaw":0,"roll":30},{"t":2.4,"pitch":-150,"yaw":0,"roll":15}],"leftArm":[{"t":0,"pitch":-50,"yaw":0,"roll":-30},{"t":0.6,"pitch":-150,"yaw":0,"roll":-15},{"t":1.2,"pitch":-50,"yaw":0,"roll":-30},{"t":1.8,"pitch":-150,"yaw":0,"roll":-15},{"t":2.4,"pitch":-50,"yaw":0,"roll":-30}],"body":[{"t":0,"pitch":0,"yaw":10,"roll":3},{"t":0.6,"pitch":0,"yaw":-10,"roll":-3},{"t":1.2,"pitch":0,"yaw":10,"roll":3},{"t":1.8,"pitch":0,"yaw":-10,"roll":-3},{"t":2.4,"pitch":0,"yaw":10,"roll":3}],"head":[{"t":0,"pitch":0,"yaw":0,"roll":8},{"t":0.6,"pitch":0,"yaw":0,"roll":-8},{"t":1.2,"pitch":0,"yaw":0,"roll":8},{"t":1.8,"pitch":0,"yaw":0,"roll":-8},{"t":2.4,"pitch":0,"yaw":0,"roll":8}],"rightLeg":[{"t":0,"pitch":25,"yaw":0,"roll":0},{"t":0.6,"pitch":-25,"yaw":0,"roll":0},{"t":1.2,"pitch":25,"yaw":0,"roll":0},{"t":1.8,"pitch":-25,"yaw":0,"roll":0},{"t":2.4,"pitch":25,"yaw":0,"roll":0}],"leftLeg":[{"t":0,"pitch":-25,"yaw":0,"roll":0},{"t":0.6,"pitch":25,"yaw":0,"roll":0},{"t":1.2,"pitch":-25,"yaw":0,"roll":0},{"t":1.8,"pitch":25,"yaw":0,"roll":0},{"t":2.4,"pitch":-25,"yaw":0,"roll":0}]}}
                """);
    }

    private SampleEmotes() {
    }
}
