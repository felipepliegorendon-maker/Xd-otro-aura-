package dev.auramotion.anim;

import dev.auramotion.config.AuraMotionConfig;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * EXPERIMENTAL (config bentLimbs, off by default). Splits the player's arms and legs into an upper and a lower
 * half at model-bake time so elbows and knees can bend. Needs a game restart (or F3+T) after toggling.
 * Every step is wrapped in try/catch and falls back to the vanilla model if names differ.
 * Armor and held items use their own rigid models, so the bend is disabled for a limb that has armor on it
 * (chest -> elbows, legs/feet -> knees) and for an arm that holds an item.
 */
public final class BentLimbs {
    private BentLimbs() {
    }

    /** The lower halves and their outer-layer halves, resolved once per model instance. */
    public static final class Parts {
        final ModelPart rightForearm, leftForearm, rightShin, leftShin;
        final ModelPart rightForearmWear, leftForearmWear, rightShinWear, leftShinWear;

        Parts(ModelPart rf, ModelPart lf, ModelPart rs, ModelPart ls,
              ModelPart rfw, ModelPart lfw, ModelPart rsw, ModelPart lsw) {
            this.rightForearm = rf;
            this.leftForearm = lf;
            this.rightShin = rs;
            this.leftShin = ls;
            this.rightForearmWear = rfw;
            this.leftForearmWear = lfw;
            this.rightShinWear = rsw;
            this.leftShinWear = lsw;
        }
    }

    // ---------- model-bake time ----------

    public static void split(ModelData data, Dilation dil, boolean slim) {
        if (!AuraMotionConfig.get().bentLimbs) {
            return;
        }
        try {
            ModelPartData root = data.getRoot();
            float armW = slim ? 3.0F : 4.0F;
            float armPivotY = slim ? 2.5F : 2.0F;
            float rightArmX = slim ? -2.0F : -3.0F;
            splitLimb(root, "right_arm", "right_forearm", "right_sleeve", "right_forearm_sleeve",
                    40, 16, 40, 32, rightArmX, -2.0F, armW, -5.0F, armPivotY, dil);
            splitLimb(root, "left_arm", "left_forearm", "left_sleeve", "left_forearm_sleeve",
                    32, 48, 48, 48, -1.0F, -2.0F, armW, 5.0F, armPivotY, dil);
            splitLimb(root, "right_leg", "right_shin", "right_pants", "right_shin_pants",
                    0, 16, 0, 32, -2.0F, 0.0F, 4.0F, -1.9F, 12.0F, dil);
            splitLimb(root, "left_leg", "left_shin", "left_pants", "left_shin_pants",
                    16, 48, 0, 48, -2.0F, 0.0F, 4.0F, 1.9F, 12.0F, dil);
        } catch (Throwable ignored) {
            // Unknown model layout: keep vanilla.
        }
    }

    private static void splitLimb(ModelPartData root, String name, String lowerName, String wearName,
                                  String lowerWearName, int u, int v, int wu, int wv,
                                  float x0, float y0, float w, float px, float py, Dilation dil) {
        final float half = 6.0F;
        Dilation wearDil = dil.add(0.25F);
        // Upper half (replaces the full-length part; same pivot as vanilla).
        ModelPartData upper = root.addChild(name,
                ModelPartBuilder.create().uv(u, v).cuboid(x0, y0, -2.0F, w, half, 4.0F, dil),
                ModelTransform.of(px, py, 0.0F, 0.0F, 0.0F, 0.0F));
        upper.addChild(wearName,
                ModelPartBuilder.create().uv(wu, wv).cuboid(x0, y0, -2.0F, w, half, 4.0F, wearDil),
                ModelTransform.NONE);
        // Lower half, hinged at the elbow/knee. Texture rows continue 6 px further down.
        ModelPartData lower = upper.addChild(lowerName,
                ModelPartBuilder.create().uv(u, v + 6).cuboid(x0, 0.0F, -2.0F, w, half, 4.0F, dil),
                ModelTransform.of(0.0F, y0 + half, 0.0F, 0.0F, 0.0F, 0.0F));
        lower.addChild(lowerWearName,
                ModelPartBuilder.create().uv(wu, wv + 6).cuboid(x0, 0.0F, -2.0F, w, half, 4.0F, wearDil),
                ModelTransform.NONE);
    }

    // ---------- runtime ----------

    public static Parts resolve(PlayerEntityModel m) {
        try {
            ModelPart rf = m.rightArm.getChild("right_forearm");
            ModelPart lf = m.leftArm.getChild("left_forearm");
            ModelPart rs = m.rightLeg.getChild("right_shin");
            ModelPart ls = m.leftLeg.getChild("left_shin");
            return new Parts(rf, lf, rs, ls,
                    rf.getChild("right_forearm_sleeve"), lf.getChild("left_forearm_sleeve"),
                    rs.getChild("right_shin_pants"), ls.getChild("left_shin_pants"));
        } catch (Throwable t) {
            return null;
        }
    }

    public static void resetFor(PlayerEntityModel m) {
        if (!AuraMotionConfig.get().bentLimbs) {
            return;
        }
        Parts p = resolve(m);
        if (p != null) {
            reset(p);
        }
    }

    public static void reset(Parts p) {
        p.rightForearm.pitch = 0.0F;
        p.leftForearm.pitch = 0.0F;
        p.rightShin.pitch = 0.0F;
        p.leftShin.pitch = 0.0F;
    }

    /** Elbow: pitch - = hand toward the front. Knee: pitch + = foot toward the back. */
    public static void pose(PlayerEntityModel m, Parts p, PlayerMotionState s, float movement, float k) {
        float run = s.lean;
        float rw = movement * (0.25F + 0.75F * run);
        float t = MathHelper.clamp(rw * k, 0.0F, 1.0F);
        RunProfile prof = RunProfile.of(AuraMotionConfig.get().runStyle);

        float rideElbow = s.chestArmor ? 0.0F : 0.65F * s.rideW;
        float rideKnee = s.legArmor ? 0.0F : 0.5F * s.rideW;
        p.rightForearm.pitch = -Math.max(elbow(t, m.rightArm.pitch, s.rightHandBusy || s.chestArmor, prof),
                s.rightHandBusy ? 0.0F : rideElbow);
        p.leftForearm.pitch = -Math.max(elbow(t, m.leftArm.pitch, s.leftHandBusy || s.chestArmor, prof),
                s.leftHandBusy ? 0.0F : rideElbow);
        // Jump tuck, falling reach and landing squat bend the knees; landing also bends the elbows a little.
        float airKnee = s.legArmor ? 0.0F : (0.7F * s.rise + 0.3F * s.fall + 1.1F * s.land) * k;
        float heroW = MathHelper.clamp(s.hero * 2.0F, 0.0F, 1.0F);
        float landElbow = s.chestArmor ? 0.0F : (0.3F * s.land * k + 0.6F * heroW);
        p.rightForearm.pitch -= s.rightHandBusy ? 0.0F : landElbow;
        p.leftForearm.pitch -= s.leftHandBusy ? 0.0F : landElbow;
        p.rightShin.pitch = (s.legArmor ? 0.0F : knee(t, m.rightLeg.pitch, prof)) + rideKnee + airKnee
                + (s.legArmor ? 0.0F : 0.5F * heroW);
        p.leftShin.pitch = (s.legArmor ? 0.0F : knee(t, m.leftLeg.pitch, prof)) + rideKnee + airKnee
                + (s.legArmor ? 0.0F : 1.2F * heroW);

        p.rightForearmWear.visible = m.rightSleeve.visible;
        p.leftForearmWear.visible = m.leftSleeve.visible;
        p.rightShinWear.visible = m.rightPants.visible;
        p.leftShinWear.visible = m.leftPants.visible;
    }

    private static float elbow(float t, float armPitch, boolean blocked, RunProfile prof) {
        if (blocked) {
            return 0.0F;
        }
        float forward = MathHelper.clamp(-armPitch, -0.5F, 1.0F);
        return t * MathHelper.clamp(prof.elbow + prof.elbowSlope * forward, 0.0F, 1.8F);
    }

    private static float knee(float t, float legPitch, RunProfile prof) {
        float back = MathHelper.clamp(legPitch / 1.6F, 0.0F, 1.0F);
        float front = MathHelper.clamp(-legPitch / 1.4F, 0.0F, 1.0F);
        return t * (0.25F + prof.kneeBack * back + prof.kneeFront * front);
    }
}
