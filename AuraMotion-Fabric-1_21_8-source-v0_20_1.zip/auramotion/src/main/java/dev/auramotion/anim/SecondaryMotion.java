package dev.auramotion.anim;

import dev.auramotion.config.AuraMotionConfig;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Applies small additive rotations on top of the vanilla pose.
 * Rotation-only on purpose: pivots are left alone to stay compatible with other mods.
 * Sign convention: body/head pitch + = forward; right arm roll + / left arm roll - = outward;
 * arm pitch - = forward/up; body yaw - = right shoulder forward.
 */
public final class SecondaryMotion {
    private SecondaryMotion() {
    }

    private static void applyCore(PlayerEntityModel model, PlayerMotionState s, float age,
                                  float limbAmplitude, float limbProgress) {
        AuraMotionConfig c = AuraMotionConfig.get();
        float k = c.intensity * s.master;
        if (k <= 0.001F) {
            return;
        }
        float armK = k * s.armWeight;
        float movement = MathHelper.clamp(limbAmplitude, 0.0F, 1.0F);

        if (c.idleBreathing) {
            float idleWeight = 1.0F - movement;
            if (idleWeight > 0.01F) {
                float phase = age * 0.075F + s.phase;
                float idle = MathHelper.sin(phase) * 0.018F * (1.0F + 2.0F * s.weak) * idleWeight * armK;
                model.rightArm.roll += idle;
                model.leftArm.roll -= idle;
                model.body.yaw += MathHelper.sin(phase * 0.5F) * 0.006F * idleWeight * k;
                // slow weight shift and tiny glances so standing still does not look frozen
                model.body.roll += MathHelper.sin(age * 0.03F + s.phase) * 0.02F * idleWeight * k;
                model.head.yaw += MathHelper.sin(age * 0.021F + s.phase * 2.0F) * 0.05F * idleWeight * k;
            }
        }

        if (c.walkSway) {
            float gait = MathHelper.sin(limbProgress * 0.5F);
            model.body.yaw += gait * 0.012F * movement * k;
        }

        boolean athletic = !"classic".equals(c.runStyle);
        if (athletic) {
            applyAthletic(model, s, c, k, movement);
        }

        if (!athletic && c.sprintLean && s.lean > 0.001F) {
            float lean = s.lean * k;
            model.body.pitch += lean * 0.14F;
            model.head.pitch += lean * 0.05F; // the head is not a child of the torso: + tilts it forward
        }

        if (!athletic && c.runDetail && movement > 0.05F) {
            float run = s.lean; // 0 walking .. 1 sprinting
            float w = movement * (0.35F + 0.65F * run) * k;
            // Stronger shoulder/hip drive (scales the vanilla swing, so it stays in phase).
            float armDrive = 1.0F + 0.30F * run * armK;
            model.rightArm.pitch *= armDrive;
            model.leftArm.pitch *= armDrive;
            float legDrive = 1.0F + 0.15F * run * k;
            model.rightLeg.pitch *= legDrive;
            model.leftLeg.pitch *= legDrive;
            // Torso counter-twist follows the arms; head keeps looking forward.
            float twist = (model.rightArm.pitch - model.leftArm.pitch) * 0.05F * w * s.armWeight;
            model.body.yaw += twist;
            model.head.yaw -= twist;
            // Hip sway follows the legs.
            float sway = (model.rightLeg.pitch - model.leftLeg.pitch) * 0.0125F * w;
            model.body.roll += sway;
            model.head.roll -= sway;
            // Arms open slightly when sprinting.
            float out = 0.07F * run * armK;
            model.rightArm.roll += out;
            model.leftArm.roll -= out;
        }

        if (c.turnFollow && Math.abs(s.turn) > 0.002F) {
            // Torso lags slightly behind the turn; arms trail outward on the swing side.
            model.body.yaw -= s.turn * 0.10F * k;
            float trail = s.turn * 0.12F * armK;
            model.rightArm.roll += Math.max(0.0F, -trail);
            model.leftArm.roll -= Math.max(0.0F, trail);
        }

        if (c.sprintLean && s.skid > 0.02F) {
            // Braking after a sprint: lean back, legs plant forward, arms flare.
            float sk = s.skid * k;
            model.body.pitch -= 0.55F * sk;
            model.head.pitch -= 0.10F * sk;
            model.rightLeg.pitch -= 0.30F * sk;
            model.leftLeg.pitch -= 0.30F * sk;
            model.rightArm.roll += 0.25F * sk * s.armWeight;
            model.leftArm.roll -= 0.25F * sk * s.armWeight;
        }

        if (c.airPose && s.air > 0.001F) {
            float out = (0.10F * s.air + 0.35F * s.fall) * armK;
            model.rightArm.roll += out;
            model.leftArm.roll -= out;
            float up = s.rise * 0.28F * armK;
            model.rightArm.pitch -= up;
            model.leftArm.pitch -= up;
            model.rightLeg.roll += 0.10F * s.fall * k; // falling: legs spread a little
            model.leftLeg.roll -= 0.10F * s.fall * k;
            // jump stride: one knee comes up, the other trails
            model.rightLeg.pitch -= 0.25F * s.rise * k;
            model.leftLeg.pitch += 0.10F * s.rise * k;
        }

        if (c.landingImpact && s.land > 0.001F) {
            float land = s.land * k;
            model.body.pitch += land * 0.18F;
            model.head.pitch += land * 0.10F;
            model.rightLeg.pitch -= 0.30F * land; // squat: thighs forward
            model.leftLeg.pitch -= 0.30F * land;
            dropAll(model, 3.0F * land); // hips come down with the squat
            float spread = land * 0.20F * s.armWeight;
            model.rightArm.roll += spread;
            model.leftArm.roll -= spread;
        }

        if (c.swingAnimations && s.swing > 0.001F) {
            applySwing(model, s, k);
        }
    }

    /** Lowers the whole model (hips included) by px model pixels, e.g. for squats and kneeling. */
    private static void dropAll(PlayerEntityModel m, float px) {
        if (px < 0.05F) {
            return;
        }
        m.body.originY += px;
        m.head.originY += px;
        m.rightArm.originY += px;
        m.leftArm.originY += px;
        m.rightLeg.originY += px;
        m.leftLeg.originY += px;
    }

    /** Standing pose: the full overlay. */
    public static void apply(PlayerEntityModel model, PlayerMotionState s, float age,
                             float limbAmplitude, float limbProgress) {
        float basePitch = model.body.pitch;
        float headPitch0 = model.head.pitch;
        float headYaw0 = model.head.yaw;
        applyCore(model, s, age, limbAmplitude, limbProgress);
        ambient(model, s, age, limbAmplitude, 0, headPitch0, headYaw0);
        finishLean(model, basePitch);
    }

    /** Other vanilla poses we decorate: 1 = sneaking, 2 = swimming. */
    public static void applyOther(PlayerEntityModel model, PlayerMotionState s, int poseId, float age,
                                  float limbAmplitude) {
        float basePitch = model.body.pitch;
        ambient(model, s, age, limbAmplitude, poseId, model.head.pitch, model.head.yaw);
        finishLean(model, basePitch);
    }

    /** The torso rotates around its top (the neck); make it behave as if it pivoted at the hips. */
    private static void finishLean(PlayerEntityModel model, float basePitch) {
        float dPitch = model.body.pitch - basePitch;
        if (Math.abs(dPitch) > 0.002F) {
            shiftUpper(model, dPitch);
        }
    }

    /** Climbing, strafe/backpedal lean, item use, sneak detail and swim undulation (config ambientAnimations). */
    private static void ambient(PlayerEntityModel m, PlayerMotionState s, float age, float limbAmplitude, int poseId,
                                float headPitch0, float headYaw0) {
        AuraMotionConfig c = AuraMotionConfig.get();
        if (!c.ambientAnimations || Quality.level >= 2) {
            return;
        }
        float k = c.intensity;
        float mv = MathHelper.clamp(limbAmplitude, 0.0F, 1.0F);

        // The spine follows where the head looks (down at the ground, up at the sky, to the sides).
        if (poseId < 2) {
            m.body.pitch += headPitch0 * 0.12F * k;
            m.body.yaw += headYaw0 * 0.15F * k;
        }

        // Smooth the vanilla snap when crouching / standing up.
        if (s.crouchT < 1.0F && poseId < 2) {
            float e = 1.0F - s.crouchT * s.crouchT * (3.0F - 2.0F * s.crouchT);
            if (poseId == 1 && s.wasCrouch) {
                m.body.pitch -= 0.5F * e * Math.min(k, 1.0F);
            } else if (poseId == 0 && !s.wasCrouch) {
                m.body.pitch += 0.5F * e * Math.min(k, 1.0F);
            }
        }

        // Treading water: legs paddle, arms scull.
        if (poseId == 0 && s.treadW > 0.01F) {
            float w = MathHelper.clamp(s.treadW * k, 0.0F, 1.0F);
            float f = MathHelper.sin(age * 0.45F + s.phase);
            m.rightLeg.pitch = MathHelper.lerp(w * 0.8F, m.rightLeg.pitch, f * 0.45F);
            m.leftLeg.pitch = MathHelper.lerp(w * 0.8F, m.leftLeg.pitch, -f * 0.45F);
            m.rightArm.roll += (0.25F + 0.20F * f) * w;
            m.leftArm.roll -= (0.25F - 0.20F * f) * w;
        }

        // Long fall: arms and legs flail.
        float flail = MathHelper.clamp((s.fall - 0.4F) / 0.5F, 0.0F, 1.0F);
        if (poseId == 0 && flail > 0.01F && s.treadW < 0.5F) {
            float w = flail * k;
            float f = MathHelper.sin(age * 0.9F + s.phase);
            m.rightArm.pitch += f * 0.35F * w;
            m.leftArm.pitch -= f * 0.35F * w;
            m.rightLeg.pitch += f * 0.20F * w;
            m.leftLeg.pitch -= f * 0.20F * w;
        }

        // Strafe / backpedal: lean into the sideways direction, lean back when walking backwards.
        if (poseId < 2 && mv > 0.15F && (Math.abs(s.side) > 0.05F || s.fwd < -0.05F)) {
            float back = MathHelper.clamp(-s.fwd, 0.0F, 1.0F);
            m.body.pitch -= 0.07F * back * mv * k;
            float roll = -s.side * 0.07F * mv * k;
            m.body.roll += roll;
            m.head.roll -= roll * 0.8F;
        }

        if (poseId == 1) {
            // Sneaking: torso follows the arm swing a little, hips sway.
            float twist = (m.rightArm.pitch - m.leftArm.pitch) * 0.04F * mv * k;
            m.body.yaw += twist;
            m.head.yaw -= twist;
            float sway = (m.rightLeg.pitch - m.leftLeg.pitch) * 0.02F * mv * k;
            m.body.roll += sway;
            m.head.roll -= sway;
        } else if (poseId == 2) {
            // Swimming: the body undulates.
            float wave = MathHelper.sin(age * 0.35F + s.phase) * mv * k;
            m.body.yaw += wave * 0.12F;
            m.head.yaw -= wave * 0.10F;
            m.body.roll += wave * 0.04F;
        }

        // Climbing: arms reach up alternately, legs step.
        if (poseId == 0 && s.climb > 0.01F) {
            float w = MathHelper.clamp(s.climb * k, 0.0F, 1.0F);
            float a = MathHelper.sin(s.climbPhase);
            m.rightArm.pitch = MathHelper.lerp(w, m.rightArm.pitch, -2.45F + 0.45F * a);
            m.leftArm.pitch = MathHelper.lerp(w, m.leftArm.pitch, -2.45F - 0.45F * a);
            m.rightArm.roll = MathHelper.lerp(w, m.rightArm.roll, 0.15F);
            m.leftArm.roll = MathHelper.lerp(w, m.leftArm.roll, -0.15F);
            m.rightLeg.pitch = MathHelper.lerp(w, m.rightLeg.pitch, -0.25F - 0.50F * (0.5F - 0.5F * a));
            m.leftLeg.pitch = MathHelper.lerp(w, m.leftLeg.pitch, -0.25F - 0.50F * (0.5F + 0.5F * a));
            m.body.pitch += 0.06F * w;
        }

        // Very low health: hunched, arms hanging in, and a limp while moving.
        if (c.lowHealthPose && s.weak > 0.01F && poseId < 2) {
            float w = s.weak * k;
            m.body.pitch += 0.10F * w;
            m.head.pitch += 0.08F * w;
            m.rightArm.roll -= 0.05F * w;
            m.leftArm.roll += 0.05F * w;
            if (mv > 0.1F) {
                m.leftLeg.pitch *= 1.0F - 0.30F * w * mv;
                m.body.roll += (m.rightLeg.pitch - m.leftLeg.pitch) * 0.04F * w;
            }
        }

        // Superhero landing after a very long fall: one knee down, fist on the ground.
        if (poseId == 0 && s.hero > 0.01F) {
            float hw = MathHelper.clamp(s.hero * 2.0F, 0.0F, 1.0F) * Math.min(k, 1.5F);
            m.body.pitch += 0.45F * hw;
            m.head.pitch -= 0.25F * hw;
            m.rightLeg.pitch -= 1.2F * hw;
            m.leftLeg.pitch += 0.9F * hw;
            m.rightArm.pitch -= 0.3F * hw;
            m.rightArm.roll += 0.10F * hw;
            m.leftArm.pitch += 0.6F * hw;
            m.leftArm.roll -= 0.25F * hw;
            dropAll(m, 6.0F * hw);
        }

        // Levitation / slow falling: weightless, arms drifting out.
        if (poseId == 0 && s.floatW > 0.01F) {
            float w = MathHelper.clamp(s.floatW * k, 0.0F, 1.0F);
            float sway = MathHelper.sin(age * 0.08F + s.phase);
            m.rightArm.roll += (0.40F + 0.10F * sway) * w;
            m.leftArm.roll -= (0.40F - 0.10F * sway) * w;
            m.rightArm.pitch -= 0.15F * w;
            m.leftArm.pitch -= 0.15F * w;
            m.rightLeg.pitch -= 0.10F * w;
            m.leftLeg.pitch += 0.06F * w;
        }

        // Springy flinch: strength follows the damage taken; knees buckle a little.
        if (c.hitReaction && s.flinchT < 0.6F && poseId < 2) {
            float env = 1.0F - s.flinchT / 0.6F;
            env *= env;
            float x = s.flinchSev * env * MathHelper.cos(s.flinchT * 16.0F) * k * 0.7F;
            m.body.pitch -= 0.30F * x;
            m.head.pitch -= 0.25F * x;
            m.rightArm.roll += 0.40F * Math.abs(x);
            m.leftArm.roll -= 0.40F * Math.abs(x);
            float buckle = s.flinchSev * env * k * 0.7F;
            m.rightLeg.pitch -= 0.15F * buckle;
            m.leftLeg.pitch -= 0.15F * buckle;
            dropAll(m, 1.5F * buckle);
        }

        // On fire: arms flail, torso twists.
        if (s.fireW > 0.01F && poseId < 2) {
            float w = s.fireW * k;
            float f = MathHelper.sin(age * 2.4F + s.phase);
            m.rightArm.pitch += (f * 0.7F - 0.3F) * w;
            m.leftArm.pitch += (-f * 0.7F - 0.3F) * w;
            m.rightArm.roll += 0.30F * w;
            m.leftArm.roll -= 0.30F * w;
            m.body.yaw += f * 0.12F * w;
            m.head.roll += f * 0.10F * w;
        }

        // Freezing (powder snow): shivering, arms tucked in, hunched.
        if (s.freezeW > 0.01F && poseId < 2) {
            float w = s.freezeW * k;
            float sh = MathHelper.sin(age * 3.1F + s.phase);
            m.body.roll += sh * 0.04F * w;
            m.head.roll -= sh * 0.03F * w;
            m.rightArm.roll -= 0.15F * w;
            m.leftArm.roll += 0.15F * w;
            m.body.pitch += 0.06F * w;
            m.head.pitch += 0.05F * w;
        }

        // Running out of air: panicked thrashing.
        if (s.drownW > 0.01F && poseId < 2) {
            float w = s.drownW * k;
            float f = MathHelper.sin(age * 2.0F + s.phase);
            m.rightArm.pitch += f * 0.9F * w - 0.5F * w;
            m.leftArm.pitch += -f * 0.9F * w - 0.5F * w;
            m.rightLeg.pitch += f * 0.5F * w;
            m.leftLeg.pitch -= f * 0.5F * w;
            m.head.pitch -= 0.25F * w;
        }

        // Loaded crossbow: aiming stance.
        if (s.xbowW > 0.01F && poseId < 2) {
            float w = s.xbowW * k;
            m.body.pitch -= 0.03F * w;
            m.rightLeg.pitch -= 0.08F * w;
            m.leftLeg.pitch += 0.08F * w;
        }

        // Idle gestures while standing still.
        if (c.idleFidgets && poseId == 0 && Quality.level == 0) {
            IdleFidgets.apply(m, s, k);
        }

        // Riding.
        if (poseId == 0 && s.rideW > 0.01F) {
            float w = MathHelper.clamp(s.rideW * k, 0.0F, 1.0F);
            if (s.mountKind == 1) {
                float sp = MathHelper.clamp(s.rideSpeed / 0.30F, 0.0F, 1.0F);
                m.body.pitch += (0.04F + 0.14F * sp) * w; // lean into the gallop
                float bob = MathHelper.sin(s.ridePhase) * sp * w;
                m.body.pitch += bob * 0.04F;
                m.head.pitch -= bob * 0.04F; // head stays steadier than the torso
                m.rightArm.pitch = MathHelper.lerp(w, m.rightArm.pitch, -0.95F); // hands on the reins
                m.leftArm.pitch = MathHelper.lerp(w, m.leftArm.pitch, -0.95F);
                m.rightArm.roll = MathHelper.lerp(w, m.rightArm.roll, -0.10F);
                m.leftArm.roll = MathHelper.lerp(w, m.leftArm.roll, 0.10F);
            } else if (s.mountKind == 2) {
                float row = MathHelper.clamp(s.rideSpeed / 0.12F, 0.0F, 1.0F);
                float stroke = MathHelper.sin(s.ridePhase) * 0.55F * row;
                float wr = w * (0.35F + 0.65F * row);
                m.rightArm.pitch = MathHelper.lerp(wr, m.rightArm.pitch, -0.9F + stroke);
                m.leftArm.pitch = MathHelper.lerp(wr, m.leftArm.pitch, -0.9F - stroke);
                m.rightArm.roll += 0.12F * wr;
                m.leftArm.roll -= 0.12F * wr;
                m.body.pitch += (0.04F + 0.05F * MathHelper.sin(s.ridePhase * 2.0F)) * wr;
            }
        }

        // Elytra: glide (wings spread), dive (arms pinned back), rocket boost (arms forward), banking in turns.
        if (poseId == 3) {
            float w = MathHelper.clamp(s.glideW * k, 0.0F, 1.0F);
            float dive = MathHelper.clamp((-s.vyS - 0.3F) / 1.0F, 0.0F, 1.0F);
            float climb = MathHelper.clamp((s.vyS - 0.1F) / 0.6F, 0.0F, 1.0F);
            float glide = 1.0F - Math.max(dive, climb);
            float flutter = MathHelper.sin(age * 0.5F + s.phase) * w;
            m.rightLeg.pitch += flutter * (0.03F + 0.04F * glide) + (0.20F * dive + 0.30F * climb) * w;
            m.leftLeg.pitch += -flutter * (0.03F + 0.04F * glide) + (0.20F * dive + 0.30F * climb) * w;
            m.rightLeg.roll += 0.06F * glide * w;
            m.leftLeg.roll -= 0.06F * glide * w;
            float armBack = (0.25F + 0.45F * dive - 1.2F * climb) * w;
            m.rightArm.pitch += armBack;
            m.leftArm.pitch += armBack;
            float spread = (0.05F + 0.25F * glide) * w;
            m.rightArm.roll += spread;
            m.leftArm.roll -= spread;
            // banking: the inner arm tucks in, the outer arm extends
            float bank = MathHelper.clamp(s.turn * 1.2F, -1.0F, 1.0F) * 0.35F * w;
            m.rightArm.roll -= bank;
            m.leftArm.roll -= bank;
        }

        // Shield block: braced stance.
        if (poseId < 2 && s.blockW > 0.01F) {
            float w = MathHelper.clamp(s.blockW * k, 0.0F, 1.0F);
            m.body.pitch += 0.12F * w;
            m.head.pitch += 0.05F * w;
            m.rightLeg.pitch -= 0.20F * w;
            m.leftLeg.pitch += 0.16F * w;
        }

        // Fishing rod held out.
        if (poseId < 2 && s.fishW > 0.01F) {
            float w = s.fishW * k;
            m.body.pitch += 0.05F * w;
            m.head.pitch += 0.04F * w;
            ModelPart rod = s.swingRight ? m.rightArm : m.leftArm;
            rod.roll += MathHelper.sin(age * 0.4F) * 0.03F * w;
        }

        // Switching weapon/tool: the main arm lifts for a moment.
        if (s.equip > 0.01F) {
            float e = s.equip * s.equip * k;
            ModelPart arm = s.swingRight ? m.rightArm : m.leftArm;
            arm.pitch -= 0.45F * e;
            arm.roll += (s.swingRight ? 1.0F : -1.0F) * 0.12F * e;
        }

        // Holding a weapon, standing still: ready stance (staggered feet).
        if (poseId == 0 && s.ready > 0.01F && mv < 0.3F) {
            float w = s.ready * k * (1.0F - mv);
            m.rightLeg.pitch -= 0.06F * w;
            m.leftLeg.pitch += 0.06F * w;
        }

        // Bow/crossbow released: small recoil.
        if (s.release > 0.01F) {
            float r = s.release * s.release * k;
            m.body.pitch -= 0.06F * r;
            m.rightArm.roll += 0.20F * r;
            m.leftArm.roll -= 0.20F * r;
        }

        // Damage flinch (cosmetic only).
        if (c.hitReaction && s.hurt > 0.01F) {
            float h = s.hurt * s.hurt * k;
            m.body.pitch -= 0.28F * h;
            m.head.pitch -= 0.22F * h;
            m.rightArm.roll += 0.30F * h;
            m.leftArm.roll -= 0.30F * h;
        }

        // Item use (eating, drinking, bow/crossbow, brush, trident, goat horn).
        if (poseId != 2 && s.useW > 0.01F) {
            float w = s.useW * k;
            ModelPart main = s.swingRight ? m.rightArm : m.leftArm;
            float d = s.drawP;
            switch (s.useKind) {
                case 1 -> { // eating: chewing, the hand bobs toward the mouth
                    float chew = MathHelper.sin(age * 1.6F);
                    m.head.pitch += (0.08F + 0.08F * chew) * w;
                    m.body.pitch += 0.04F * w;
                    main.pitch += chew * 0.10F * w;
                }
                case 3 -> { // drinking: head and torso lean back
                    m.head.pitch -= 0.30F * w;
                    m.body.pitch -= 0.06F * w;
                    main.pitch -= 0.10F * w;
                }
                case 2 -> { // bow / crossbow: brace and tremble more the further it is drawn
                    m.body.pitch -= (0.04F + 0.08F * d) * w;
                    m.head.pitch += 0.03F * d * w;
                    float shake = MathHelper.sin(age * 1.3F) * (0.01F + 0.04F * d) * w;
                    m.rightArm.roll += shake;
                    m.leftArm.roll -= shake;
                    m.rightLeg.pitch -= 0.12F * w;
                    m.leftLeg.pitch += 0.12F * w;
                }
                case 5 -> { // spyglass: head tilts to the eye piece, feet planted
                    m.head.roll += 0.06F * w;
                    m.body.pitch -= 0.03F * w;
                    m.rightLeg.pitch -= 0.08F * w;
                    m.leftLeg.pitch += 0.08F * w;
                }
                case 4 -> { // brushing
                    main.pitch += MathHelper.sin(age * 1.4F) * 0.45F * w;
                    m.body.yaw += MathHelper.sin(age * 0.7F) * 0.10F * w;
                }
                case 6 -> { // trident wind-up
                    m.body.pitch -= (0.08F + 0.10F * d) * w;
                    m.rightArm.roll += MathHelper.sin(age * 1.1F) * (0.015F + 0.03F * d) * w;
                }
                case 7 -> { // goat horn
                    m.head.pitch -= 0.35F * w;
                    m.body.pitch -= 0.08F * w;
                }
                default -> {
                }
            }
        }
    }

    /**
     * Moves the neck/shoulders so a forward lean of dPitch happens around the hips: the upper body
     * moves forward and slightly down instead of the hips swinging backward away from the legs.
     * Model space: +pivotZ = backwards, +pivotY = down. Pivots are reset by vanilla every frame.
     */
    public static void shiftUpper(PlayerEntityModel m, float dPitch) {
        float sin = MathHelper.sin(dPitch);
        float cos = MathHelper.cos(dPitch);
        float topZ = 12.0F * sin;           // neck / top of torso is 12 px above the hips
        float topY = 12.0F * (1.0F - cos);
        float armZ = 10.0F * sin;           // shoulder joint is 10 px above the hips
        float armY = 10.0F * (1.0F - cos);
        m.body.originZ -= topZ;
        m.body.originY += topY;
        m.head.originZ -= topZ;
        m.head.originY += topY;
        m.rightArm.originZ -= armZ;
        m.rightArm.originY += armY;
        m.leftArm.originZ -= armZ;
        m.leftArm.originY += armY;
    }

    /**
     * Athletic run: forward lean, arms held forward and pumping (bent-arm look), legs with a longer trailing kick,
     * counter-twisting torso, head bob. Limbs are rigid in the vanilla model (no elbows/knees), so this is an
     * approximation done with rotations only. u is the vanilla swing signal (+1 = right arm fully forward).
     */
    private static void applyAthletic(PlayerEntityModel m, PlayerMotionState s, AuraMotionConfig c,
                                      float k, float movement) {
        RunProfile p = RunProfile.of(c.runStyle);
        float run = s.lean; // 0 jog .. 1 sprint
        float rw = movement * (0.25F + 0.75F * run); // how much of the run pose applies
        float jog = movement * (1.0F - run);

        if (c.sprintLean) {
            float lean = (p.leanJog * jog + p.leanSprint * run) * k;
            m.body.pitch += lean;
            m.head.pitch += lean * p.headFollow; // 0 = gaze stays level, 0.5 = head follows half of the lean
        }
        if (!c.runDetail || rw < 0.02F) {
            return;
        }

        float t = MathHelper.clamp(rw * k, 0.0F, 1.0F);
        float ta = t * s.armWeight;
        float u = (m.leftArm.pitch - m.rightArm.pitch) * 0.5F;

        // Arms: held forward, swing mostly in front of the body, elbows tucked toward the torso.
        m.rightArm.pitch = MathHelper.lerp(ta, m.rightArm.pitch, pump(u, p));
        m.leftArm.pitch = MathHelper.lerp(ta, m.leftArm.pitch, pump(-u, p));
        m.rightArm.roll -= p.tuck * ta;
        m.leftArm.roll += p.tuck * ta;

        // Legs: longer trailing kick, slightly higher knee.
        m.rightLeg.pitch = kick(m.rightLeg.pitch, t, p);
        m.leftLeg.pitch = kick(m.leftLeg.pitch, t, p);

        // Torso counter-twist, head stays level; bob twice per stride; hip sway.
        float twist = -u * p.twist * rw * k * s.armWeight;
        m.body.yaw += twist;
        m.head.yaw -= twist;
        m.head.pitch += (0.5F - Math.abs(u)) * p.bob * rw * k;
        float sway = (m.rightLeg.pitch - m.leftLeg.pitch) * p.sway * rw * k;
        m.body.roll += sway;
        m.head.roll -= sway;
    }

    private static float pump(float u, RunProfile p) {
        return u > 0.0F ? -p.armBase - p.armFwd * u : -p.armBase - p.armBack * u;
    }

    private static float kick(float pitch, float t, RunProfile p) {
        return pitch > 0.0F ? pitch * (1.0F + p.kickBack * t) : pitch * (1.0F + p.kickFront * t);
    }

    /** Follow-through on top of vanilla's swing (peak of vanilla's strike is around p = 0.2). */
    private static void applySwing(PlayerEntityModel model, PlayerMotionState s, float k) {
        float p = MathHelper.clamp(s.swing, 0.0F, 1.0F);
        float inv = 1.0F - p;
        float strike = MathHelper.sin((1.0F - inv * inv * inv) * MathHelper.PI); // matches vanilla's curve
        float bell = MathHelper.sin(p * MathHelper.PI); // slower body weight shift

        float armExtra, out, bodyAmt, headAmt, lunge;
        switch (s.swingStyle) {
            case 1 -> { armExtra = 0.15F; out = 0.20F; bodyAmt = 0.10F; headAmt = 0.04F; lunge = 0.22F; } // sword slash
            case 2 -> { armExtra = 0.35F; out = 0.08F; bodyAmt = 0.18F; headAmt = 0.10F; lunge = 0.12F; } // pickaxe
            case 3 -> { armExtra = 0.45F; out = 0.05F; bodyAmt = 0.14F; headAmt = 0.06F; lunge = 0.25F; } // throw
            case 4 -> { armExtra = 0.30F; out = 0.15F; bodyAmt = 0.14F; headAmt = 0.08F; lunge = 0.15F; } // axe
            case 5 -> { armExtra = 0.20F; out = 0.06F; bodyAmt = 0.25F; headAmt = 0.14F; lunge = 0.10F; } // shovel
            case 6 -> { armExtra = 0.25F; out = 0.30F; bodyAmt = 0.10F; headAmt = 0.06F; lunge = 0.12F; } // hoe
            case 7 -> { armExtra = 0.55F; out = 0.06F; bodyAmt = 0.30F; headAmt = 0.12F; lunge = 0.20F; } // mace smash
            default -> { armExtra = 0.20F; out = 0.10F; bodyAmt = 0.08F; headAmt = 0.04F; lunge = 0.10F; }
        }

        float dir = 1.0F;
        if (s.swingStyle == 1) {
            // 3-step sword combo: slash, reverse slash, thrust.
            if (s.combo == 1) {
                dir = -1.0F;
            } else if (s.combo == 2) {
                out = 0.0F;
                armExtra += 0.30F;
                lunge += 0.12F;
                bodyAmt += 0.04F;
            }
        }
        if (s.lean > 0.5F) { // attacking while sprinting: lunge
            lunge *= 1.5F;
            bodyAmt += 0.06F * s.lean;
        }
        if (s.air > 0.5F && s.fall > 0.2F) { // falling attack: bigger overhead swing
            armExtra += 0.35F;
            bodyAmt += 0.10F;
            headAmt += 0.05F;
        }

        ModelPart arm = s.swingRight ? model.rightArm : model.leftArm;
        float side = s.swingRight ? 1.0F : -1.0F;
        arm.pitch -= strike * armExtra * k;
        arm.roll += side * dir * strike * out * k;

        model.body.pitch += bell * bodyAmt * k;
        model.head.pitch += bell * headAmt * k;

        // Weight shift: the leg opposite the swinging arm steps forward.
        ModelPart front = s.swingRight ? model.leftLeg : model.rightLeg;
        ModelPart back = s.swingRight ? model.rightLeg : model.leftLeg;
        front.pitch -= bell * lunge * k;
        back.pitch += bell * lunge * 0.6F * k;
    }
}
