package dev.auramotion.anim;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Small additive gestures played at random while a player stands still (looking around, stretching, shaking out
 * the arms, checking a wrist, hands on hips, neck roll, shifting weight, rocking on the heels).
 * Tracks are {part, t, pitch, yaw, roll, t, pitch, yaw, roll, ...} in degrees; parts: 0 head, 1 body, 2 right arm,
 * 3 left arm, 4 right leg, 5 left leg.
 */
public final class IdleFidgets {
    public static final int COUNT = 8;

    private static final float[] LENGTH = {3.2F, 2.6F, 1.8F, 2.4F, 3.0F, 2.2F, 2.8F, 3.0F};

    private static final float[][][] TRACKS = {
        // look_around
        {
            {0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5F, 0.0F, -35.0F, 0.0F, 1.2F, 0.0F, -35.0F, 0.0F, 1.7F, 0.0F, 35.0F, 0.0F, 2.4F, 0.0F, 35.0F, 0.0F, 3.2F, 0.0F, 0.0F, 0.0F},
            {1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5F, 0.0F, -8.0F, 0.0F, 1.2F, 0.0F, -8.0F, 0.0F, 1.7F, 0.0F, 8.0F, 0.0F, 2.4F, 0.0F, 8.0F, 0.0F, 3.2F, 0.0F, 0.0F, 0.0F},
        },
        // stretch
        {
            {2.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5F, -170.0F, 0.0F, 10.0F, 1.9F, -170.0F, 0.0F, 10.0F, 2.6F, 0.0F, 0.0F, 0.0F},
            {3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5F, -170.0F, 0.0F, -10.0F, 1.9F, -170.0F, 0.0F, -10.0F, 2.6F, 0.0F, 0.0F, 0.0F},
            {1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5F, -8.0F, 0.0F, 0.0F, 1.9F, -8.0F, 0.0F, 0.0F, 2.6F, 0.0F, 0.0F, 0.0F},
            {0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5F, -12.0F, 0.0F, 0.0F, 1.9F, -12.0F, 0.0F, 0.0F, 2.6F, 0.0F, 0.0F, 0.0F},
        },
        // shake_arms
        {
            {2.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.2F, -20.0F, 0.0F, 30.0F, 0.4F, -20.0F, 0.0F, -5.0F, 0.6F, -20.0F, 0.0F, 30.0F, 0.8F, -20.0F, 0.0F, -5.0F, 1.0F, -20.0F, 0.0F, 25.0F, 1.8F, 0.0F, 0.0F, 0.0F},
            {3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.2F, -20.0F, 0.0F, -30.0F, 0.4F, -20.0F, 0.0F, 5.0F, 0.6F, -20.0F, 0.0F, -30.0F, 0.8F, -20.0F, 0.0F, 5.0F, 1.0F, -20.0F, 0.0F, -25.0F, 1.8F, 0.0F, 0.0F, 0.0F},
            {1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.3F, 0.0F, 0.0F, 3.0F, 0.5F, 0.0F, 0.0F, -3.0F, 0.7F, 0.0F, 0.0F, 3.0F, 1.8F, 0.0F, 0.0F, 0.0F},
        },
        // check_wrist
        {
            {2.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.4F, -80.0F, 0.0F, -30.0F, 1.9F, -80.0F, 0.0F, -30.0F, 2.4F, 0.0F, 0.0F, 0.0F},
            {0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.4F, 14.0F, 0.0F, 0.0F, 1.9F, 14.0F, 0.0F, 0.0F, 2.4F, 0.0F, 0.0F, 0.0F},
        },
        // hands_on_hips
        {
            {2.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.4F, 8.0F, 0.0F, 38.0F, 2.6F, 8.0F, 0.0F, 38.0F, 3.0F, 0.0F, 0.0F, 0.0F},
            {3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.4F, 8.0F, 0.0F, -38.0F, 2.6F, 8.0F, 0.0F, -38.0F, 3.0F, 0.0F, 0.0F, 0.0F},
            {1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.4F, -3.0F, 0.0F, 0.0F, 2.6F, -3.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, 0.0F},
        },
        // neck_roll
        {
            {0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.4F, 0.0F, 0.0F, 12.0F, 0.9F, 0.0F, 0.0F, -12.0F, 1.4F, 10.0F, 0.0F, 0.0F, 1.8F, -6.0F, 0.0F, 0.0F, 2.2F, 0.0F, 0.0F, 0.0F},
        },
        // weight_shift
        {
            {1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6F, 0.0F, 0.0F, 4.0F, 1.4F, 0.0F, 0.0F, 4.0F, 2.2F, 0.0F, 0.0F, -3.0F, 2.8F, 0.0F, 0.0F, 0.0F},
            {4.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6F, -10.0F, 0.0F, 0.0F, 1.4F, -10.0F, 0.0F, 0.0F, 2.2F, 6.0F, 0.0F, 0.0F, 2.8F, 0.0F, 0.0F, 0.0F},
            {5.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6F, 6.0F, 0.0F, 0.0F, 1.4F, 6.0F, 0.0F, 0.0F, 2.2F, -10.0F, 0.0F, 0.0F, 2.8F, 0.0F, 0.0F, 0.0F},
        },
        // rock_heels
        {
            {1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5F, 5.0F, 0.0F, 0.0F, 1.0F, -5.0F, 0.0F, 0.0F, 1.5F, 5.0F, 0.0F, 0.0F, 2.0F, -5.0F, 0.0F, 0.0F, 2.5F, 3.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, 0.0F},
            {0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.5F, -3.0F, 0.0F, 0.0F, 1.0F, 3.0F, 0.0F, 0.0F, 1.5F, -3.0F, 0.0F, 0.0F, 2.0F, 3.0F, 0.0F, 0.0F, 2.5F, -2.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, 0.0F},
        },
    };

    private IdleFidgets() {
    }

    public static float length(int fidget) {
        return LENGTH[fidget];
    }

    private static ModelPart part(PlayerEntityModel m, int id) {
        return switch (id) {
            case 0 -> m.head;
            case 1 -> m.body;
            case 2 -> m.rightArm;
            case 3 -> m.leftArm;
            case 4 -> m.rightLeg;
            default -> m.leftLeg;
        };
    }

    /** Adds the current gesture, scaled by its fade weight. */
    public static void apply(PlayerEntityModel m, PlayerMotionState s, float k) {
        if (s.fidget < 0 || s.fidgetW < 0.01F) {
            return;
        }
        float w = s.fidgetW * Math.min(k, 1.5F) * MathHelper.RADIANS_PER_DEGREE;
        float t = s.fidgetT;
        for (float[] tr : TRACKS[s.fidget]) {
            ModelPart p = part(m, (int) tr[0]);
            int n = (tr.length - 1) / 4;
            int i = 0;
            while (i < n - 1 && t > tr[1 + (i + 1) * 4]) {
                i++;
            }
            float t0 = tr[1 + i * 4];
            float f = 0.0F;
            int j = i;
            if (i < n - 1) {
                float t1 = tr[1 + (i + 1) * 4];
                f = MathHelper.clamp((t - t0) / Math.max(1.0E-4F, t1 - t0), 0.0F, 1.0F);
                f = f * f * (3.0F - 2.0F * f);
                j = i + 1;
            }
            float pitch = tr[2 + i * 4] + (tr[2 + j * 4] - tr[2 + i * 4]) * f;
            float yaw = tr[3 + i * 4] + (tr[3 + j * 4] - tr[3 + i * 4]) * f;
            float roll = tr[4 + i * 4] + (tr[4 + j * 4] - tr[4 + i * 4]) * f;
            p.pitch += pitch * w;
            p.yaw += yaw * w;
            p.roll += roll * w;
        }
    }
}
