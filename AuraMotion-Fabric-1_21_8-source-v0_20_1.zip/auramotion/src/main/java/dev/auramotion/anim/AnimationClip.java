package dev.auramotion.anim;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A keyframe clip loaded from JSON. Angles are in degrees in the file, radians at runtime.
 * Parts: head, body, rightArm, leftArm, rightLeg, leftLeg. Missing channels default to 0.
 */
public final class AnimationClip {
    public final String name;
    public final float length;
    public final boolean loop;
    private final Map<String, List<Key>> tracks;

    private record Key(float time, float pitch, float yaw, float roll) {
    }

    private AnimationClip(String name, float length, boolean loop, Map<String, List<Key>> tracks) {
        this.name = name;
        this.length = length;
        this.loop = loop;
        this.tracks = tracks;
    }

    public static AnimationClip parse(String name, JsonObject root) {
        float length = root.has("length") ? Math.max(0.1F, root.get("length").getAsFloat()) : 1.0F;
        boolean loop = root.has("loop") && root.get("loop").getAsBoolean();
        Map<String, List<Key>> tracks = new HashMap<>();
        JsonObject t = root.has("tracks") ? root.getAsJsonObject("tracks") : new JsonObject();
        for (Map.Entry<String, JsonElement> e : t.entrySet()) {
            List<Key> keys = new ArrayList<>();
            JsonArray arr = e.getValue().getAsJsonArray();
            for (JsonElement el : arr) {
                JsonObject k = el.getAsJsonObject();
                keys.add(new Key(
                        num(k, "t"),
                        num(k, "pitch") * MathHelper.RADIANS_PER_DEGREE,
                        num(k, "yaw") * MathHelper.RADIANS_PER_DEGREE,
                        num(k, "roll") * MathHelper.RADIANS_PER_DEGREE));
            }
            keys.sort(Comparator.comparingDouble(Key::time));
            if (!keys.isEmpty()) {
                tracks.put(e.getKey(), keys);
            }
        }
        return new AnimationClip(name, length, loop, tracks);
    }

    private static float num(JsonObject o, String key) {
        return o.has(key) ? o.get(key).getAsFloat() : 0.0F;
    }

    public boolean hasTrack(String part) {
        return tracks.containsKey(part);
    }

    /** @param out receives pitch, yaw, roll in radians; returns false when the part has no track. */
    public boolean sample(String part, float time, float[] out) {
        List<Key> keys = tracks.get(part);
        if (keys == null) {
            return false;
        }
        Key first = keys.get(0);
        if (time <= first.time) {
            return set(out, first);
        }
        Key last = keys.get(keys.size() - 1);
        if (time >= last.time) {
            return set(out, last);
        }
        for (int i = 1; i < keys.size(); i++) {
            Key b = keys.get(i);
            if (time <= b.time) {
                Key a = keys.get(i - 1);
                float span = Math.max(1.0E-4F, b.time - a.time);
                float f = (time - a.time) / span;
                f = f * f * (3.0F - 2.0F * f); // smoothstep
                out[0] = MathHelper.lerp(f, a.pitch, b.pitch);
                out[1] = MathHelper.lerp(f, a.yaw, b.yaw);
                out[2] = MathHelper.lerp(f, a.roll, b.roll);
                return true;
            }
        }
        return set(out, last);
    }

    private static boolean set(float[] out, Key k) {
        out[0] = k.pitch;
        out[1] = k.yaw;
        out[2] = k.roll;
        return true;
    }
}
