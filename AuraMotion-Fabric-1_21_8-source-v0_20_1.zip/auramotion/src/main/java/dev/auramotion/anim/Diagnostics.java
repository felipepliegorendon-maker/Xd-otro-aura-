package dev.auramotion.anim;

/** Counters for /auramotion status: they show whether the mixins are really running in the game. */
public final class Diagnostics {
    public static long modelApplies;
    public static long trackerCalls;
    public static PlayerMotionState local;

    private Diagnostics() {
    }
}
