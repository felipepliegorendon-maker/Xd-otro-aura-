package dev.auramotion.ui;

import dev.auramotion.AuraMotionKeys;
import dev.auramotion.anim.AnimationManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Radial emote wheel (client only). Click or tap a sector to play that emote; the center circle stops the current one.
 * Mouse wheel / the "<" ">" buttons change page when there are more than eight emotes.
 */
public final class EmoteWheelScreen extends Screen {
    private static final int PER_PAGE = 6;
    private static final Map<String, String> LABELS = Map.of(
            "wave", "Saludar", "bow", "Reverencia", "salute", "Saludo", "cheer", "Celebrar",
            "clap", "Aplaudir", "point", "Señalar", "think", "Pensar", "shrug", "Encogerse");

    private final List<String> names;
    private final Map<Integer, List<int[]>> spanCache = new HashMap<>();
    private int page;
    private int cx;
    private int cy;
    private int rOut;
    private int rIn;

    public EmoteWheelScreen() {
        super(Text.literal("Emotes"));
        this.names = AnimationManager.names();
    }

    @Override
    protected void init() {
        cx = this.width / 2;
        cy = this.height / 2 - 4;
        int m = Math.min(this.width, this.height);
        rOut = Math.max(40, (int) (m * 0.38F));
        rIn = (int) (rOut * 0.34F);
        spanCache.clear();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static String label(String name) {
        String l = LABELS.get(name);
        if (l != null) {
            return l;
        }
        switch (name) {
            case "flex":
                return "Presumir";
            case "dance":
                return "Bailar";
            default:
                return name.isEmpty() ? name : Character.toUpperCase(name.charAt(0)) + name.substring(1);
        }
    }

    private int pages() {
        return Math.max(1, (names.size() + PER_PAGE - 1) / PER_PAGE);
    }

    private int countOnPage() {
        return Math.max(0, Math.min(PER_PAGE, names.size() - page * PER_PAGE));
    }

    // ---------- geometry ----------

    private int sectorAt(int x, int y, int n, double sector) {
        double r2 = (double) x * x + (double) y * y;
        if (r2 > (double) rOut * rOut) {
            return -1;
        }
        double inner = rIn - 2.0D;
        if (r2 < inner * inner) {
            return -2; // center (stop button)
        }
        if (r2 < (double) rIn * rIn) {
            return -1;
        }
        double a = Math.atan2(x, -y);
        if (a < 0.0D) {
            a += 2.0D * Math.PI;
        }
        int idx = Math.min(n - 1, (int) (a / sector));
        double frac = a - idx * sector;
        double edge = 1.6D / Math.sqrt(r2);
        return (frac < edge || frac > sector - edge) ? -1 : idx;
    }

    /** Horizontal runs {dy, dx1, dx2, sector} for the wheel, built once per sector count. */
    private List<int[]> spans(int n) {
        return spanCache.computeIfAbsent(n, this::buildSpans);
    }

    private List<int[]> buildSpans(int n) {
        List<int[]> out = new ArrayList<>();
        double sector = 2.0D * Math.PI / n;
        for (int y = -rOut; y <= rOut; y++) {
            boolean open = false;
            int runStart = 0;
            int runSector = -1;
            for (int x = -rOut; x <= rOut; x++) {
                int sec = sectorAt(x, y, n, sector);
                if (open && sec != runSector) {
                    out.add(new int[]{y, runStart, x, runSector});
                    open = false;
                }
                if (!open && sec != -1) {
                    open = true;
                    runStart = x;
                    runSector = sec;
                }
            }
            if (open) {
                out.add(new int[]{y, runStart, rOut + 1, runSector});
            }
        }
        return out;
    }

    private int hovered(double mx, double my, int n) {
        double dx = mx - cx;
        double dy = my - cy;
        double r = Math.sqrt(dx * dx + dy * dy);
        if (r < rIn - 2.0D) {
            return -2;
        }
        if (r < rIn || r > rOut || n <= 0) {
            return -1;
        }
        double a = Math.atan2(dx, -dy);
        if (a < 0.0D) {
            a += 2.0D * Math.PI;
        }
        return Math.min(n - 1, (int) (a / (2.0D * Math.PI / n)));
    }

    private int navY() {
        return cy + rOut + 8;
    }

    private boolean inBox(double mx, double my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx <= x2 && my >= y1 && my <= y2;
    }

    // ---------- rendering ----------

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0x88000000);
        int n = countOnPage();
        if (n <= 0) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("No hay emotes en config/auramotion/animations"),
                    cx, cy, 0xFFFFFFFF);
            return;
        }
        int hover = hovered(mouseX, mouseY, n);
        for (int[] s : spans(n)) {
            int color;
            if (s[3] == -2) {
                color = hover == -2 ? 0xDDC0392B : 0xCC1B2430;
            } else if (s[3] == hover) {
                color = 0xDD1FA67A;
            } else {
                color = (s[3] & 1) == 0 ? 0xCC121B27 : 0xCC1A2634;
            }
            ctx.fill(cx + s[1], cy + s[0], cx + s[2], cy + s[0] + 1, color);
        }

        int mid = (rIn + rOut) / 2;
        int start = page * PER_PAGE;
        for (int i = 0; i < n; i++) {
            double a = (i + 0.5D) * 2.0D * Math.PI / n;
            int x = cx + (int) Math.round(Math.sin(a) * mid);
            int y = cy - (int) Math.round(Math.cos(a) * mid) - 4;
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(label(names.get(start + i))),
                    x, y, hover == i ? 0xFFFFFFFF : 0xFFCFD8E3);
        }
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Parar"), cx, cy - 4, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Emotes"), cx, cy - rOut - 14, 0xFF7FE8C8);

        if (pages() > 1) {
            int y = navY();
            boolean overLeft = inBox(mouseX, mouseY, cx - 70, y, cx - 40, y + 12);
            boolean overRight = inBox(mouseX, mouseY, cx + 40, y, cx + 70, y + 12);
            ctx.fill(cx - 70, y, cx - 40, y + 12, overLeft ? 0xDD1FA67A : 0xCC121B27);
            ctx.fill(cx + 40, y, cx + 70, y + 12, overRight ? 0xDD1FA67A : 0xCC121B27);
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("<"), cx - 55, y + 2, 0xFFFFFFFF);
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(">"), cx + 55, y + 2, 0xFFFFFFFF);
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal((page + 1) + "/" + pages()),
                    cx, y + 2, 0xFFCFD8E3);
        }
    }

    // ---------- input ----------

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }
        if (pages() > 1) {
            int y = navY();
            if (inBox(mouseX, mouseY, cx - 70, y, cx - 40, y + 12)) {
                changePage(-1);
                return true;
            }
            if (inBox(mouseX, mouseY, cx + 40, y, cx + 70, y + 12)) {
                changePage(1);
                return true;
            }
        }
        int n = countOnPage();
        int h = hovered(mouseX, mouseY, n);
        if (h == -2) {
            AnimationManager.stop();
            this.close();
        } else if (h >= 0) {
            AnimationManager.play(names.get(page * PER_PAGE + h));
            AuraMotionKeys.onEmoteStarted();
            this.close();
        } else {
            this.close();
        }
        return true;
    }

    private void changePage(int delta) {
        page = Math.floorMod(page + delta, pages());
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (pages() > 1 && verticalAmount != 0.0D) {
            changePage(verticalAmount < 0.0D ? 1 : -1);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (AuraMotionKeys.OPEN != null && AuraMotionKeys.OPEN.matchesKey(keyCode, scanCode)) {
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
