package dev.auramotion;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.auramotion.anim.AnimationManager;
import dev.auramotion.anim.Diagnostics;
import dev.auramotion.anim.PlayerMotionState;
import dev.auramotion.anim.MotionTracker;
import dev.auramotion.anim.PerfStats;
import dev.auramotion.config.AuraMotionConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;

public final class AuraMotionClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        AuraMotionConfig.load();
        AnimationManager.load();
        AuraMotionKeys.init();

        // Client-side only, no networking.
        // /auramotion reload | toggle | intensity <0-2> | play <emote> | stop | list
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("auramotion")
                        .then(ClientCommandManager.literal("reload").executes(ctx -> {
                            AuraMotionConfig.load();
                            AnimationManager.load();
                            MotionTracker.clear();
                            ctx.getSource().sendFeedback(Text.literal("AuraMotion: configuración y emotes recargados"));
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("toggle").executes(ctx -> {
                            AuraMotionConfig cfg = AuraMotionConfig.get();
                            cfg.enabled = !cfg.enabled;
                            MotionTracker.clear();
                            AuraMotionConfig.save();
                            ctx.getSource().sendFeedback(Text.literal(
                                    "AuraMotion: " + (cfg.enabled ? "activado" : "desactivado")));
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("intensity")
                                .then(ClientCommandManager.argument("value", FloatArgumentType.floatArg(0.0F, 2.0F))
                                        .executes(ctx -> {
                                            float v = FloatArgumentType.getFloat(ctx, "value");
                                            AuraMotionConfig.get().setIntensity(v);
                                            AuraMotionConfig.save();
                                            ctx.getSource().sendFeedback(Text.literal("AuraMotion: intensidad " + v));
                                            return 1;
                                        })))
                        .then(ClientCommandManager.literal("play")
                                .then(ClientCommandManager.argument("emote", StringArgumentType.word())
                                        .suggests((ctx, builder) ->
                                                CommandSource.suggestMatching(AnimationManager.names(), builder))
                                        .executes(ctx -> {
                                            String name = StringArgumentType.getString(ctx, "emote");
                                            boolean ok = AnimationManager.play(name);
                                            if (ok) {
                                                AuraMotionKeys.onEmoteStarted();
                                            }
                                            ctx.getSource().sendFeedback(Text.literal(ok
                                                    ? "AuraMotion: reproduciendo " + name + " (usa la vista en tercera persona, F5)"
                                                    : "AuraMotion: no existe el emote " + name));
                                            return ok ? 1 : 0;
                                        })))
                        .then(ClientCommandManager.literal("runstyle")
                                .then(ClientCommandManager.literal("athletic").executes(ctx -> {
                                    AuraMotionConfig.get().setRunStyle("athletic");
                                    AuraMotionConfig.save();
                                    ctx.getSource().sendFeedback(Text.literal("AuraMotion: carrera atlética"));
                                    return 1;
                                }))
                                .then(ClientCommandManager.literal("fresh").executes(ctx -> {
                                    AuraMotionConfig.get().setRunStyle("fresh");
                                    AuraMotionConfig.save();
                                    ctx.getSource().sendFeedback(Text.literal("AuraMotion: carrera fresh"));
                                    return 1;
                                }))
                                .then(ClientCommandManager.literal("action").executes(ctx -> {
                                    AuraMotionConfig.get().setRunStyle("action");
                                    AuraMotionConfig.save();
                                    ctx.getSource().sendFeedback(Text.literal("AuraMotion: carrera action"));
                                    return 1;
                                }))
                                .then(ClientCommandManager.literal("classic").executes(ctx -> {
                                    AuraMotionConfig.get().setRunStyle("classic");
                                    AuraMotionConfig.save();
                                    ctx.getSource().sendFeedback(Text.literal("AuraMotion: carrera clásica"));
                                    return 1;
                                })))
                        .then(ClientCommandManager.literal("bend")
                                .then(ClientCommandManager.literal("on").executes(ctx -> {
                                    AuraMotionConfig.get().bentLimbs = true;
                                    AuraMotionConfig.save();
                                    ctx.getSource().sendFeedback(Text.literal(
                                            "AuraMotion: codos y rodillas ON (experimental). Reinicia el juego o pulsa F3+T"));
                                    return 1;
                                }))
                                .then(ClientCommandManager.literal("off").executes(ctx -> {
                                    AuraMotionConfig.get().bentLimbs = false;
                                    AuraMotionConfig.save();
                                    ctx.getSource().sendFeedback(Text.literal(
                                            "AuraMotion: codos y rodillas OFF. Reinicia el juego o pulsa F3+T"));
                                    return 1;
                                })))
                        .then(ClientCommandManager.literal("perf").executes(ctx -> {
                            if (!PerfStats.enabled) {
                                PerfStats.start();
                                ctx.getSource().sendFeedback(Text.literal(
                                        "AuraMotion: midiendo. Juega unos segundos y repite /auramotion perf"));
                            } else {
                                ctx.getSource().sendFeedback(Text.literal(PerfStats.reportAndReset()));
                            }
                            return 1;
                        }).then(ClientCommandManager.literal("off").executes(ctx -> {
                            PerfStats.stop();
                            ctx.getSource().sendFeedback(Text.literal("AuraMotion: medición apagada"));
                            return 1;
                        })))
                        .then(ClientCommandManager.literal("status").executes(ctx -> {
                            AuraMotionConfig cfg = AuraMotionConfig.get();
                            ctx.getSource().sendFeedback(Text.literal("AuraMotion · activado: " + cfg.enabled
                                    + " · intensidad: " + cfg.intensity + " · carrera: " + cfg.runStyle
                                    + " · bend: " + cfg.bentLimbs));
                            ctx.getSource().sendFeedback(Text.literal("Calidad automática: nivel " + dev.auramotion.anim.Quality.level
                                    + " (0 completa, 1 reducida, 2 mínima) · activada: " + cfg.adaptiveQuality));
                            ctx.getSource().sendFeedback(Text.literal("Emotes cargados: " + AnimationManager.names().size()
                                    + " · animaciones ambientales: " + cfg.ambientAnimations
                                    + " · golpes: " + cfg.swingAnimations));
                            ctx.getSource().sendFeedback(Text.literal("Modelo aplicado " + Diagnostics.modelApplies
                                    + " veces, seguimiento " + Diagnostics.trackerCalls + " llamadas"
                                    + (Diagnostics.modelApplies == 0
                                    ? " -> el mixin del modelo NO se está aplicando (ve en tercera persona F5 o revisa el log)"
                                    : " -> funcionando")));
                            PlayerMotionState s = Diagnostics.local;
                            if (s != null) {
                                ctx.getSource().sendFeedback(Text.literal("Ítem en mano: tipo de golpe " + s.heldStyle
                                        + " (0 otro, 1 espada, 2 pico, 3 lanzable, 4 hacha, 5 pala, 6 azada, 7 maza)"
                                        + " · uso actual " + s.useKind + " (1 comer, 2 arco, 3 beber, 4 cepillo, 6 tridente, 7 cuerno)"
                                        + " · peso de uso " + String.format("%.2f", s.useW)));
                            }
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("wheel").executes(ctx -> {
                            AuraMotionKeys.requestWheel();
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("stop").executes(ctx -> {
                            AnimationManager.stop();
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("list").executes(ctx -> {
                            ctx.getSource().sendFeedback(Text.literal(
                                    "AuraMotion emotes: " + String.join(", ", AnimationManager.names())));
                            return 1;
                        }))));
    }
}
